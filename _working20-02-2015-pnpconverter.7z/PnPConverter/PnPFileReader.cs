﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;

namespace PnPConverter
{
  class PnPFileReader
  {
    public static List<PnPPart> ReadPnPFile(FileInfo PnPFile, out bool IsMetricFile, out bool ReadErrors)
    {
      if (!PnPFile.Exists)
        throw new FileNotFoundException("The targeted Pick and Place file does not exist.");

      List<PnPPart> xComponentList = new List<PnPPart>();
      FileStream xStream = new FileStream(PnPFile.FullName, FileMode.Open);
      StreamReader xReader = new StreamReader(xStream);
      bool bReadErrors = false, bMetricFile = true;
      //try
      //{
        while (!xReader.EndOfStream)
        {
          string sComponentString = xReader.ReadLine();
          if (!sComponentString.Equals(null))
          {
            sComponentString = sComponentString.Trim();
            if (!sComponentString.ToLower().StartsWith("\"designator") && !sComponentString.StartsWith("\"\"") && !sComponentString.Equals(string.Empty))
            {
              string[] sParams = sComponentString.Split(new char[] {','});
              if (sParams.Length == 11)
              {
                for (int i = 0; i < sParams.Length; i++)
                  sParams[i] = sParams[i].Trim(new char[] {'"'});

                string sDesignator = sParams[0];
                PnPFootprint xFootprint = new PnPFootprint();
                xFootprint.Name = sParams[1];
                //string sFootprint = sParams[1];
                //float fMidX = 0, fMidY = 0, fRefX = 0, fRefY = 0, fPadX = 0, fPadY = 0;

                PnPPartCoordinates xCoordinates = new PnPPartCoordinates();
                
                // read MidX
                if (IsMetric(sParams[2]))
                  xCoordinates.MidX = ToMetricFloat(sParams[2]);
                else
                  bMetricFile = false;
                
                // read MidY
                if (IsMetric(sParams[3]))
                  xCoordinates.MidY = ToMetricFloat(sParams[3]);
                else
                  bMetricFile = false;

                // read RefX
                if (IsMetric(sParams[4]))
                  xCoordinates.RefX = ToMetricFloat(sParams[4]);
                else
                  bMetricFile = false;

                // read RefY
                if (IsMetric(sParams[5]))
                  xCoordinates.RefY = ToMetricFloat(sParams[5]);
                else
                  bMetricFile = false;

                // read PadX
                if (IsMetric(sParams[6]))
                  xCoordinates.PadX = ToMetricFloat(sParams[6]);
                else
                  bMetricFile = false;

                // read PadY
                if (IsMetric(sParams[7]))
                  xCoordinates.PadY = ToMetricFloat(sParams[7]);
                else
                  bMetricFile = false;

                PCBLayer xLayer;
                if (sParams[8].Trim().ToUpper().Equals("T"))
                  xLayer = PCBLayer.TopLayer;
                else if (sParams[8].Trim().ToUpper().Equals("B"))
                  xLayer = PCBLayer.BottomLayer;
                else
                  xLayer = PCBLayer.Undefined;

                float fRotation;
                if (!float.TryParse(sParams[9], out fRotation))
                  fRotation = 0;
                CultureInfo xDecPoint = new CultureInfo("en-US");
                fRotation = Convert.ToSingle(sParams[9], xDecPoint);
                fRotation = fRotation % (float)360;

                string sPartNumberOrValue = sParams[10];

                PnPPart xPart = new PnPPart(
                  sDesignator,
                  xFootprint,
                  sPartNumberOrValue,
                  xLayer,
                  xCoordinates,
                  fRotation
                );
                  
                xComponentList.Add(xPart);
              }
              else
                bReadErrors = true;
            }
          }
        }
      //}
      //catch (IOException ioe)
      //{
      //  return null;
      //}
      //catch (Exception e)
      //{
      //  return null;
      //}

      xReader.Close();
      xReader.Dispose();
      xStream.Close();
      xStream.Dispose();

      IsMetricFile = bMetricFile;
      ReadErrors = bReadErrors;
      return xComponentList;

    }

    private static bool IsMetric(string Value)
    { 
      return Value.ToLower().EndsWith("mm");
    }

    private static float ToMetricFloat(string Value)
    {
      if (!IsMetric(Value))
        return 0;

      string sNumeric = Value.Substring(0, Value.Length - 2);
      float fValue;
      if (!float.TryParse(sNumeric, out fValue))
        return 0;

      //CultureInfo[] xCulture = CultureInfo.GetCultures(CultureTypes.AllCultures);
      CultureInfo xDecPoint = new CultureInfo("en-US");
      fValue = Convert.ToSingle(sNumeric, xDecPoint);

      return fValue;
    }   
  }
}
