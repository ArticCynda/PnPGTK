﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PnPConverter
{
  public partial class NewProjectWizard : Form
  {
    public NewProjectWizard()
    {
      InitializeComponent();
    }

    private enum WizardState
    {
      Intro,
      ImportPnPFile,
      ImportLibs,
      ReviewParts,
      AddReels,
      Project,
      Phases,
      Finish
    }
    private WizardState _xState = WizardState.Intro;

    private void NewPCBWizard_Load(object sender, EventArgs e)
    {
      btnNext.Select();
    }

    private void NextStep(object sender, EventArgs e)
    {
      switch (_xState)
      { 
        case WizardState.Intro:
          _xState = WizardState.ImportPnPFile;
          break;
        case WizardState.ImportPnPFile:
          _xState = WizardState.ImportLibs;
          break;
        case WizardState.ImportLibs:
          _xState = WizardState.ReviewParts;
          break;
        case WizardState.ReviewParts:
          _xState = WizardState.AddReels;
          break;
        case WizardState.AddReels:
          _xState = WizardState.Project;
          break;
        case WizardState.Project:
          _xState = WizardState.Phases;
          break;
        case WizardState.Phases:
          _xState = WizardState.Finish;
          break;
      }
      UpdatePanelLayout();
    }

    private void PreviousStep(object sender, EventArgs e)
    {
      switch (_xState)
      {
        case WizardState.Intro:
          _xState = WizardState.Intro;
          break;
        case WizardState.ImportPnPFile:
          _xState = WizardState.Intro;
          break;
        case WizardState.ImportLibs:
          _xState = WizardState.ImportPnPFile;
          break;
        case WizardState.ReviewParts:
          _xState = WizardState.ImportLibs;
          break;
        case WizardState.AddReels:
          _xState = WizardState.ReviewParts;
          break;
        case WizardState.Project:
          _xState = WizardState.AddReels;
          break;
        case WizardState.Phases:
          _xState = WizardState.Project;
          break;
      }
      UpdatePanelLayout();
    }

    private void UpdatePanelLayout()
    {
      // update the user controls based on the state the form is in:
      switch (_xState)
      {
        case WizardState.Intro:
          this.btnBack.Enabled = false;
          this.pnlSelectPnP.Visible = false;
          this.pnlIntro.Visible = true;
          break;
        case WizardState.ImportPnPFile:
          this.btnBack.Enabled = true;
          this.pnlIntro.Visible = false;
          this.pnlSelectLib.Visible = false;
          this.pnlSelectPnP.Visible = true;
          break;
        case WizardState.ImportLibs:
          this.pnlReviewParts.Visible = false;
          this.pnlSelectPnP.Visible = false;
          this.pnlSelectLib.Visible = true;
          this.ResumeLayout(true);
          LoadPcbLibs();
          break;
        case WizardState.ReviewParts:
          this.pnlSelectLib.Visible = false;
          this.pnlAddReels.Visible = false;
          this.pnlReviewParts.Visible = true;
          this.btnNext.Enabled = true;
          this.ResumeLayout(true);
          this.Cursor = Cursors.WaitCursor;
          SavePcbLibs();
          CollectFootprints();
          AssembleSummary();
          UpdatePartSummary();
          this.Cursor = Cursors.Default;
          break;
        case WizardState.AddReels:
          //this.btnNext.Text = "&Next";
          this.pnlProjectProperties.Visible = false;
          this.pnlReviewParts.Visible = false;
          this.pnlAddReels.Visible = true;
          this.Cursor = Cursors.WaitCursor;
          LoadReelCollection();
          IdentifyMissingReels();
          LoadMissingReelList();
          LoadReelList();
          this.Cursor = Cursors.Default;
          break;
        case WizardState.Project:
          this.btnNext.Text = "&Next";
          this.pnlAddReels.Visible = false;
          this.pnlPhases.Visible = false;
          this.pnlProjectProperties.Visible = true;
          this.Cursor = Cursors.WaitCursor;
          SaveNewReels();
          LoadProjectName();
          this.Cursor = Cursors.Default;
          break;
        case WizardState.Phases:
          this.btnNext.Text = "E&xport";
          this.pnlProjectProperties.Visible = false;
          this.pnlPhases.Visible = true;
          this.Cursor = Cursors.WaitCursor;
          GeneratePhases();
          DisplayPhases();
          this.Cursor = Cursors.Default;
          break;
        case WizardState.Finish:
          UpdateStackConfiguration();
          ExportFiles();
          MessageBox.Show("wizard finished!");
          break;
      }

    }

    /// <summary>
    /// The Altium Designer export file with raw pick and place data.
    /// </summary>
    private FileInfo _xPnPFile;

    /// <summary>
    /// List of parts described in the Altium Designer export file.
    /// </summary>
    private List<PnPPart> _xPnPFilePartsList;
    private void BrowsePnPFile(object sender, EventArgs e)
    {
      OpenFileDialog xBrowsePnPFile = new OpenFileDialog();
      xBrowsePnPFile.Title = "Select Pick and Place file...";
      xBrowsePnPFile.Filter = "Altium Pick and Place File|*.csv|All Files|*.*";
      xBrowsePnPFile.FileName = "D:\\Dropbox\\InformaticaCSharp\\ProjectOOP\\WeatherStation\\Project Outputs for WeatherStation-v2\\Generate Files\\Pick Place\\Pick Place for WeatherStation-v2.csv";
      if (xBrowsePnPFile.ShowDialog() == DialogResult.OK)
      {
        // when OK is clicked, it is already checked that the file does exist.
        this.Cursor = Cursors.WaitCursor;
        bool bMetricFile, bReadErrors;
        _xPnPFile = new FileInfo(xBrowsePnPFile.FileName);
        _xPnPFilePartsList = PnPFileReader.ReadPnPFile(_xPnPFile, out bMetricFile, out bReadErrors);
      
        if (!bReadErrors)
        {
          // PnP file was successfully analyzed
          this.picPnPOK.Visible = true;
          this.picPnPNOK.Visible = false;
          this.lblPartPreviewMessage.Text = "PnP file is valid, data for " + _xPnPFilePartsList.Count.ToString() + " parts was imported.";

          this.listPartPreview.Items.Clear();
          foreach (PnPPart xCurPart in _xPnPFilePartsList)
          {
            string[] sPartListParams = new string[2];
            sPartListParams[0] = xCurPart.Designator;
            sPartListParams[1] = xCurPart.Footprint.Name;
            ListViewItem xPartListEntry = new ListViewItem(sPartListParams);
            this.listPartPreview.Items.Add(xPartListEntry);
          }
        }
        else
        {
          // errors occurred while reading the PnP file
          this.picPnPNOK.Visible = true;
          this.picPnPOK.Visible = false;
          this.lblPartPreviewMessage.Text = "The selected file is not a valid PnP file.";
        }
        this.Cursor = Cursors.Default;
      }
      xBrowsePnPFile.Dispose();
      
    }

    private void LoadPcbLibs()
    {
      // first load the existing libraries into the list view
      //ConfigManager.ConfigValues xSmdFootprints = ConfigManager.ConfigReader();
      this.listLibraries.Clear();

      List<FileInfo> xSmdLibs = ConfigManager.GetSmdLibraries();
      foreach (FileInfo xSmdLib in xSmdLibs)
        this.listLibraries.Items.Add(xSmdLib.FullName);

      UpdatePcbLibs();
    }

    private void SavePcbLibs()
    {
      // save the selected libraries to disk
      //ConfigManager.ConfigValues xSmdFootprints;
      //xSmdFootprints.SmdLibs = new List<FileInfo>();
      List<FileInfo> xSmdLibs = new List<FileInfo>();
      foreach (ListViewItem xLib in this.listLibraries.Items)
      {
        FileInfo xCurLib = new FileInfo(xLib.Text);
        xSmdLibs.Add(xCurLib);
      }

      
      //ConfigManager.ConfigWriter(xSmdFootprints);
      ConfigManager.SetSmdLibraries(xSmdLibs);
      //MessageBox.Show("configuration successfully stored on disk!");

    }

    private void UpdatePcbLibs()
    {
      //MessageBox.Show("updating pcblibs!");
      this.lblFootprintCount.Text = "Searching for footprints...";
      this.Cursor = Cursors.WaitCursor;
      int iFootprintCount = 0;
      foreach (ListViewItem xPcbLibrary in this.listLibraries.Items)
      {
        if (xPcbLibrary.Tag == null)
        {
          List<PnPFootprint> xCurFootprints = ADLibReader.GetFootprints(new FileInfo(xPcbLibrary.Text));
          xPcbLibrary.Tag = xCurFootprints.Count;
          iFootprintCount += xCurFootprints.Count;
        }
        else
        {
          int iFootprints = (int)(xPcbLibrary.Tag);
          iFootprintCount += iFootprints;
        }
      }
      if (iFootprintCount == 0)
      {
        this.lblFootprintCount.Text = "Add library with SMD footprints used in this project.";
      }
      else
      {
        this.lblFootprintCount.Text = "A total of " + iFootprintCount.ToString();
        if (iFootprintCount == 1)
          this.lblFootprintCount.Text += " valid footprint was found in " + this.listLibraries.Items.Count.ToString();
        else
          this.lblFootprintCount.Text += " valid footprints were found in " + this.listLibraries.Items.Count.ToString();
        
        if (this.listLibraries.Items.Count == 1)
          this.lblFootprintCount.Text += " library.";
        else
          this.lblFootprintCount.Text += " libraries.";
      }
      //this.lblFootprintCount.Text = "A total of " + iFootprintCount.ToString() + " valid footprints was detected in " + this.listLibraries.Items.Count.ToString() + " libraries.";
      this.Cursor = Cursors.Default;
    }

    private void AddPcbLib(object sender, EventArgs e)
    {
      OpenFileDialog xBrowseLib = new OpenFileDialog();
      xBrowseLib.Filter = "Altium Designer PCB Library|*.PcbLib";
      xBrowseLib.Title = "Select Altium Designer PCB Library...";
      xBrowseLib.FileName = "D:\\Dropbox\\PCBtech\\libs\\mylibrary.PcbLib";
      if (xBrowseLib.ShowDialog() == DialogResult.OK)
      {
        this.lblFootprintCount.Text = "Checking file integrity...";
        FileInfo xLibFile = new FileInfo(xBrowseLib.FileName);
        if (ADLibReader.IsADLib(xLibFile))
        {
          this.picLibOK.Visible = true;
          this.picLibNOK.Visible = false;
          this.lblADLib.Text = "Valid Altium library selected.";
          bool bExists = false;
          foreach (ListViewItem xListItem in listLibraries.Items)
          {
            if (xListItem.Text.Equals(xLibFile.FullName))
              bExists = true;
          }
          
          if (bExists)
          {
            // TODO: messagebox customization
            MessageBox.Show("The selected library is already included.");
          }
          else
          {
            this.listLibraries.Items.Add(xLibFile.FullName);
            UpdatePcbLibs();
          }
        }
        else
        {
          this.picLibOK.Visible = false;
          this.picLibNOK.Visible = true;
          this.lblADLib.Text = "Not a valid Altium library.";
          this.lblFootprintCount.Text = "Integrity check completed.";
        }
        //this.lblFootprintCount.Text = "Integrity check completed.";
      }
    }

    private void PurgePcbLibs(object sender, EventArgs e)
    {
      bool bPurged = false;
      foreach (ListViewItem xCurLib in this.listLibraries.Items)
        if (!File.Exists(xCurLib.Text))
        {
          this.listLibraries.Items.Remove(xCurLib);
          bPurged = true;
        }
      if (!bPurged)
        MessageBox.Show("all libraries valid!");
      else
        UpdatePcbLibs();
    }

    private void RemovePcbLib(object sender, EventArgs e)
    {
      foreach (ListViewItem xCurLib in this.listLibraries.SelectedItems)
        this.listLibraries.Items.Remove(xCurLib);

      UpdatePcbLibs();
    }

    /// <summary>
    /// List of surface mount footprints to identify SMD parts
    /// </summary>
    List<PnPFootprint> _xSmdFootprints = new List<PnPFootprint>();
    private void CollectFootprints()
    {
      _xSmdFootprints.Clear();
      foreach (ListViewItem xCurLib in this.listLibraries.Items)
      {
        FileInfo xCurLibFile = new FileInfo(xCurLib.Text);
        if (ADLibReader.IsADLib(xCurLibFile))
        {
          List<PnPFootprint> xFootprints = ADLibReader.GetFootprints(xCurLibFile);
          foreach (PnPFootprint xCurFootprint in xFootprints)
            _xSmdFootprints.Add(xCurFootprint);
        }
      }
    }

    /// <summary>
    /// List of included parts in the current project.
    /// </summary>
    List<PnPPart> _xPartsList = new List<PnPPart>();
    /// <summary>
    /// List of parts in the Altium Designer export file that are excluded from the current project.
    /// </summary>
    List<PnPPart> _xExcludedPartsList = new List<PnPPart>();
    private void AssembleSummary()
    {
      _xPartsList.Clear();
      _xExcludedPartsList.Clear();

      // sort out any parts that do not have known SMD footprints
      foreach (PnPPart xCurPart in _xPnPFilePartsList)
      {
        //PnPPart xNewPart = new PnPPart(
        //  xCurPart.Designator,
        //  xCurPart.Footprint,
        //  xCurPart.Comment,
        //  xCurPart.Layer,
        //  xCurPart.Coordinates,
        //  xCurPart.Rotation,
        //  xCurPart.SkipPlacement
        //);

        bool bFootprintFound = false;
        foreach (PnPFootprint xCurFootprint in _xSmdFootprints)
        {
          if (xCurFootprint.Name.ToLower() == xCurPart.Footprint.Name.ToLower())
          {
            bFootprintFound = true;
            // copy relevant parameters and add the part to the updated list
            xCurPart.Footprint = xCurFootprint;

            // skip footprints with height zero, which are logos, mounting holes, fiducials etc.
            if (xCurFootprint.Height > 0)
            {
              if (!xCurFootprint.Name.ToLower().StartsWith("mech"))
              {
                xCurPart.ExclusionReason = ExclusionReason.None;
                _xPartsList.Add(xCurPart);
              }
              else
              {
                xCurPart.ExclusionReason = ExclusionReason.Mechanical;
                _xExcludedPartsList.Add(xCurPart);
              }
            }
            else
            {
              xCurPart.ExclusionReason = ExclusionReason.NotPhysical;
              _xExcludedPartsList.Add(xCurPart);
            }
          }
        }
        if (!bFootprintFound)
        {
          if (xCurPart.Footprint.Name.ToLower().StartsWith("mech"))
            xCurPart.ExclusionReason = ExclusionReason.Mechanical;
          else
            xCurPart.ExclusionReason = ExclusionReason.NotSmd;
          _xExcludedPartsList.Add(xCurPart);
        }
      }
    }

    private void UpdatePartSummary()
    {
      this.listPartSummary.Items.Clear();

      foreach (PnPPart xCurPart in _xPartsList)
      {
        string[] sProperties = new string[5];
        sProperties[0] = xCurPart.Designator;
        sProperties[1] = xCurPart.Footprint.Name;
        sProperties[2] = xCurPart.Footprint.Description;
        sProperties[3] = xCurPart.PartNumberOrValue;
        sProperties[4] = xCurPart.Footprint.Height.ToString() + " mm";
        ListViewItem xCurPartEntry = new ListViewItem(sProperties);
        this.listPartSummary.Items.Add(xCurPartEntry);
      }

      lnkOmittedParts.Text = "Review " + (_xPnPFilePartsList.Count - _xPartsList.Count).ToString() + " omitted parts";
    }

    private void ReviewOmittedParts(object sender, LinkLabelLinkClickedEventArgs e)
    {
      ExcludedPartsDialog xOmittedPartsDialog = new ExcludedPartsDialog();
      xOmittedPartsDialog.IncludedParts = _xPartsList;
      xOmittedPartsDialog.ExcludedParts = _xExcludedPartsList;
      if (xOmittedPartsDialog.ShowDialog() == DialogResult.OK)
      {
        // if the user clicked OK, update the lists
        _xPartsList = xOmittedPartsDialog.IncludedParts;
        _xExcludedPartsList = xOmittedPartsDialog.ExcludedParts;
        UpdatePartSummary();
      }
    }

    private void OmitSelectedParts(object sender, EventArgs e)
    {
      bool bOmitted = false;
      foreach (ListViewItem xCurPartEntry in this.listPartSummary.Items)
      {
        if (xCurPartEntry.Checked)
        {
          bOmitted = true;
          foreach (PnPPart xCurPart in _xPartsList)
          {
            if (xCurPart.Designator.ToUpper() == xCurPartEntry.SubItems[0].Text.ToUpper())
            {
              _xPartsList.Remove(xCurPart);
              xCurPart.ExclusionReason = ExclusionReason.UserDefined;
              _xExcludedPartsList.Add(xCurPart);
              break;
            }
          }
        }
      }
      if (bOmitted)
        UpdatePartSummary();
    }

    private void EnableOmitSelectedButton(object sender, ItemCheckedEventArgs e)
    {
      bool bCheckedParts = false;
      foreach (ListViewItem xCurPartEntry in this.listPartSummary.Items)
        if (xCurPartEntry.Checked)
          bCheckedParts = true;
 
      this.btnOmitSelected.Enabled = bCheckedParts;
    }

    private void EnableRemoveLibButton(object sender, EventArgs e)
    {
      this.btnRemoveLib.Enabled = (this.listLibraries.SelectedItems.Count > 0);
    }

    /// <summary>
    /// Library of available Reels.
    /// </summary>
    private List<PnPReel> _xReelLibrary = new List<PnPReel>();
    /// <summary>
    /// Parts that do not have a matching Reel in the Library.
    /// </summary>
    private List<PnPPart> _xMissingReelParts = new List<PnPPart>();
    private void LoadReelCollection()
    {
      _xReelLibrary = PnPReel.LoadReels();
    }

    private void IdentifyMissingReels()
    {
      _xMissingReelParts.Clear();
      for (int iCur = 0; iCur < _xPartsList.Count; iCur++)
      {
        PnPPart xCurPart = _xPartsList[iCur];
        bool bReelAvailable = false;
        foreach (PnPReel xCurReel in _xReelLibrary)
        {
          if (xCurReel.Footprint.Equals(xCurPart.Footprint) && xCurReel.PartNumberOrValue == xCurPart.PartNumberOrValue)
          {
            bReelAvailable = true;
            // assign this Reel to the Part:
            xCurPart.AssignedReel = xCurReel.GUID;
            break;
          }
        }

        if (!bReelAvailable)
          _xMissingReelParts.Add(xCurPart);
      }
    }

    private struct NewReelInfo
    {
      public List<string> Designators;
      public PnPFootprint Footprint;
      public string PartNameOrValue;
      public int Index; // for use in the ListView
      public bool DataOK;

      public MissingReelSolution Solution;
      public Guid GUID;
      public bool AutomaticConfig;

      public Guid ReplacementReel;
      //public string ReplacementReelDescription;
      //public string FootprintString;
      //public string PartNumber;
      public PnPSupplyPackage PackageType;
      //public float Height;
      public float XOffset, YOffset;
      public PnPMachineNozzle Nozzle;
      public float FeedSpacing;
      //public int Quantity;
      public string Manufacturer;
      public string Supplier;
      public string OrderCode;
      public int Speed;     
    }

    private enum MissingReelSolution
    {
      StandIn,
      NewReel,
      Exclude,
      Undefined
    } 

    /// <summary>
    /// List of Reels that are newly added to the Library for this project.
    /// </summary>
    private List<NewReelInfo> _xNewReelList = new List<NewReelInfo>();
    private void LoadMissingReelList()
    {
      this.listMissingReels.Items.Clear();  
      _xNewReelList.Clear(); 
    
      foreach (PnPPart xCurPart in _xMissingReelParts)
      {
        // search the list of missing reels for a match with the current part
        int iRegisteredIndex = -1;
        foreach (NewReelInfo xRegisteredPart in _xNewReelList)
        {
          if (xRegisteredPart.Footprint.Equals(xCurPart.Footprint) && xRegisteredPart.PartNameOrValue == xCurPart.PartNumberOrValue)
          {
            iRegisteredIndex = xRegisteredPart.Index;
            break;
          }
        }
        
        // if the index was found (= reel was already registered) then add it, otherwise create a new one
        if (iRegisteredIndex > -1)
        {
          foreach (NewReelInfo xPart in _xNewReelList)
            if (xPart.Index == iRegisteredIndex)
              xPart.Designators.Add(xCurPart.Designator);
        }
        else
        {
          NewReelInfo xNewReel = new NewReelInfo();
          xNewReel.Designators = new List<string>();
          xNewReel.Designators.Add(xCurPart.Designator);
          xNewReel.Footprint = xCurPart.Footprint;
          xNewReel.PartNameOrValue = xCurPart.PartNumberOrValue;
          xNewReel.Index = _xNewReelList.Count;
          xNewReel.AutomaticConfig = true;
          _xNewReelList.Add(xNewReel);
        }
      }

      // now fill the ListView with parts
      foreach (NewReelInfo xMissingReelEntry in _xNewReelList)
      {
        StringBuilder sEntry = new StringBuilder("   "); // some space between text and icon
        for (int i = 0; i < xMissingReelEntry.Designators.Count - 1; i++)
        {
          sEntry.Append(xMissingReelEntry.Designators[i]);
          sEntry.Append(", ");
        }
        sEntry.Append(xMissingReelEntry.Designators[xMissingReelEntry.Designators.Count - 1]);

        string[] sNewEntry = new string[] {sEntry.ToString(), xMissingReelEntry.Footprint.Name, xMissingReelEntry.PartNameOrValue};

        ListViewItem xNewListEntry = new ListViewItem(sNewEntry);
        xNewListEntry.Tag = xMissingReelEntry.Index;
        xNewListEntry.Tag = xMissingReelEntry.Index;
        xNewListEntry.ImageIndex = -1;
        this.listMissingReels.Items.Add(xNewListEntry);
      }

      // configure the icon
      ImageList xImages = new ImageList();
      xImages.Images.Add(GetOKImage());
      xImages.Images.Add(GetPendingImage());
      this.listMissingReels.SmallImageList = xImages;

      if (this.listMissingReels.Items.Count == 0)
      {
        // no parts with missing reels!
        this.btnNext.Enabled = true;
        this.lblMissingReels.Text = "Packaging information for all parts is available, click Next to proceed.";
      }
      else
      {
        this.btnNext.Enabled = false;
        this.lblMissingReels.Text = "Packaging information is missing for the following part(s):";

        // select the first row in the list
        this.listMissingReels.Items[0].Selected = true;
      }
    }

    private void AutomaticReelConfig()
    {
      if (_iCurrentItem == -1)
        return;

      NewReelInfo newReel = _xNewReelList[_iCurrentItem];
      if (!newReel.AutomaticConfig)
        return;

      // if this footprint already exists in the library, copy its settings
      foreach (PnPReel xCurReel in _xReelLibrary)
      {
        if (xCurReel.Footprint.Name.Trim().ToLower() == newReel.Footprint.Name.Trim().ToLower())
        {
          // footprint match
          newReel.FeedSpacing = xCurReel.FeedSpacing;
          newReel.Nozzle = xCurReel.Nozzle;
          newReel.PackageType = xCurReel.SupplyPackage;
          newReel.Speed = xCurReel.Speed;
          newReel.XOffset = xCurReel.XOffset;
          newReel.YOffset = xCurReel.YOffset;
          break;
        }
      }

      // try to deduct suitable values for jellybean parts based on their footprint
      List<string> sJellyBeans = new List<string>() {"CAP", "RES", "IND", "FUSE", "LED"};
      bool bIsJellyPart = false;
      foreach (string sCur in sJellyBeans)
        if (newReel.Footprint.Name.ToUpper().Trim().StartsWith(sCur));
          bIsJellyPart = true;

      //List<string> sJellyFormats = new List<string>() {"0402", "0603", "0805", "1206", "1210"};
      //bool bIsJellyFormat = false;
      //foreach (string sCur in sJellyFormats)
      //  if (newReel.Footprint.Name.Trim().EndsWith(sCur))
      //    bIsJellyFormat = true;

      if (bIsJellyPart)
      {
        string sFootprintSize = newReel.Footprint.Name.Trim().Substring(newReel.Footprint.Name.Trim().Length - 5);
        switch (sFootprintSize)
        {
          case "0402":
            newReel.XOffset = 0;
            newReel.YOffset = 0.05F;
            newReel.Nozzle = PnPMachineNozzle.XS;
            newReel.Footprint.Height = 0.5F;
            newReel.FeedSpacing = 2;
            newReel.Speed = 100;
            newReel.PackageType = PnPSupplyPackage.Reel8mm;
            break;
          case "0603":
            newReel.XOffset = -0.04F;
            newReel.YOffset = -0.1F;
            newReel.Nozzle = PnPMachineNozzle.S;
            newReel.Footprint.Height = 0.95F;
            newReel.FeedSpacing = 4;
            newReel.Speed = 100;
            newReel.PackageType = PnPSupplyPackage.Reel8mm;
            break;
          case "0805":
            newReel.XOffset = 0.05F;
            newReel.YOffset = 0;
            newReel.Nozzle = PnPMachineNozzle.S;
            newReel.Footprint.Height = 1.10F;
            newReel.FeedSpacing = 4;
            newReel.Speed = 90;
            newReel.PackageType = PnPSupplyPackage.Reel8mm;
            break;
          case "1206":
            newReel.XOffset = 0.23F;
            newReel.YOffset = 0;
            newReel.Nozzle = PnPMachineNozzle.M;
            newReel.Footprint.Height = 1.30F;
            newReel.FeedSpacing = 4;
            newReel.Speed = 80;
            newReel.PackageType = PnPSupplyPackage.Reel8mm;
            break;
          case "1210":
            newReel.XOffset = 0.24F;
            newReel.YOffset = 0.02F;
            newReel.Nozzle = PnPMachineNozzle.L;
            newReel.Footprint.Height = 1.40F;
            newReel.FeedSpacing = 4;
            newReel.Speed = 80;
            newReel.PackageType = PnPSupplyPackage.Reel8mm;
            break;
        }
      }

      // try to deduct values for common IC types
      string sICFootprint = newReel.Footprint.Name.Trim().ToUpper();
      if (
        sICFootprint.StartsWith("IC-SOIC-") || 
        sICFootprint.StartsWith("IC-TSSOP-") ||
        sICFootprint.StartsWith("IC-MSOP-") ||
        sICFootprint.StartsWith("IC-POWERSO-") ||
        sICFootprint.StartsWith("IC-SSOP-") ||
        sICFootprint.StartsWith("IC-VQFN-")
      )
      {
        newReel.Nozzle = PnPMachineNozzle.L;
        newReel.Footprint.Height = 2F;
        newReel.FeedSpacing = 18;
        newReel.Speed = 10;
        newReel.PackageType = PnPSupplyPackage.Tray;
      }
  
      newReel.GUID = Guid.NewGuid();
      newReel.AutomaticConfig = false;

      _xNewReelList[_iCurrentItem] = newReel;
    }

    private Image GetOKImage()
    {
      const string OKFILE = "ok.png";
      if (System.IO.File.Exists(OKFILE))
        return Image.FromFile(OKFILE);
      else
        return null;
    }

    private Image GetPendingImage()
    {
      const string PENDINGFILE = "pending.png";
      if (System.IO.File.Exists(PENDINGFILE))
        return Image.FromFile(PENDINGFILE);
      else
        return null;
    }

    private void LoadReelList()
    {
      this.comCurReplace.Items.Clear();
      foreach (PnPReel xCurReel in _xReelLibrary)
        this.comCurReplace.Items.Add(xCurReel.ToString());
    }

    private int _iCurrentItem = -1;
    private void StoreNewReelSettings()
    {
      if (_iCurrentItem == -1)
        return;

      // user has selected another part, so store the existing values into the reel info struct
      NewReelInfo xCurReel = new NewReelInfo();
      foreach (NewReelInfo xReel in _xNewReelList)
        if (xReel.Index == _iCurrentItem)
          xCurReel = xReel;

      // store the selected solution:
      if (this.rdbReplacePart.Checked)
        xCurReel.Solution = MissingReelSolution.StandIn;
      else if (this.rdbAddNew.Checked)
        xCurReel.Solution = MissingReelSolution.NewReel;
      else
        xCurReel.Solution = MissingReelSolution.Exclude;

      // if an existing reel was selected, store this info
      // DEBUG: check GUID length
      if (this.comCurReplace.SelectedIndex > -1)
      {
        string sSelectedReel = this.comCurReplace.Items[this.comCurReplace.SelectedIndex].ToString();
        string sGUID = sSelectedReel.Substring(sSelectedReel.Length - 37, 36);
        xCurReel.ReplacementReel = new Guid(sGUID);
      }
      
      // settings for new reels:
      xCurReel.Manufacturer = this.txtCurManufacturer.Text;
      xCurReel.OrderCode = this.txtCurOrderCode.Text;
      xCurReel.Supplier = this.txtCurSupplier.Text;

      //float fXOffset, fYOffset, fHeight;
      //float.TryParse(this.txtCurXOffset.Text, out xCurReel.XOffset);
      //float.TryParse(this.txtCurYOffset.Text, out xCurReel.YOffset);
      //float.TryParse(this.txtCurHeight.Text, out xCurReel.Footprint.Height);
      //float.TryParse(this.txtCurFeedSpacing.Text, out xCurReel.FeedSpacing);
      xCurReel.XOffset = ConfigManager.StringToFloat(this.txtCurXOffset.Text);
      xCurReel.YOffset = ConfigManager.StringToFloat(this.txtCurYOffset.Text);
      xCurReel.Footprint.Height = ConfigManager.StringToFloat(this.txtCurHeight.Text);
      xCurReel.FeedSpacing = ConfigManager.StringToFloat(this.txtCurFeedSpacing.Text);
      
      // store nozzle size:
      if (this.comCurNozzle.SelectedIndex > -1)
      {
        switch (this.comCurNozzle.Items[this.comCurNozzle.SelectedIndex].ToString())
        {
          case "Large":
            xCurReel.Nozzle = PnPMachineNozzle.L;
            break;
          case "Medium":
            xCurReel.Nozzle = PnPMachineNozzle.M;
            break;
          case "Small":
            xCurReel.Nozzle = PnPMachineNozzle.S;
            break;
          case "Tiny":
            xCurReel.Nozzle = PnPMachineNozzle.XS;
            break;
        }
      }
      else
      {
        xCurReel.Nozzle = PnPMachineNozzle.Undefined;
      }

      // store speed setting:
      if (this.comCurSpeed.SelectedIndex > -1)
      {
        switch (this.comCurSpeed.Items[this.comCurSpeed.SelectedIndex].ToString())
        {
          case "Very Fast":
            xCurReel.Speed = 100;
            break;
          case "Fast":
            xCurReel.Speed = 80;
            break;
          case "Medium":
            xCurReel.Speed = 50;
            break;
          case "Slow":
            xCurReel.Speed = 20;
            break;
          case "Very Slow":
            xCurReel.Speed = 10;
            break;
        }
      }
      else
      {
        xCurReel.Speed = 100; // set full speed if undefined
      }

      // store packaging information:
      if (this.comCurPackageType.SelectedIndex > -1)
      {
        switch (this.comCurPackageType.Items[this.comCurPackageType.SelectedIndex].ToString())
        {
          case "Reel, 8 mm":
            xCurReel.PackageType = PnPSupplyPackage.Reel8mm;
            break;
          case "Reel, 12 mm":
            xCurReel.PackageType = PnPSupplyPackage.Reel12mm;
            break;
          case "Reel, 16 mm":
            xCurReel.PackageType = PnPSupplyPackage.Reel16mm;
            break;
          case "Tube":
            xCurReel.PackageType = PnPSupplyPackage.Tray;
            break;
          case "Tray":
            xCurReel.PackageType = PnPSupplyPackage.Tube;
            break;
        }
      }
      else
      {
        xCurReel.PackageType = PnPSupplyPackage.Tube; // if no reel info is present, assume a tray or tube
      }

      _xNewReelList[_iCurrentItem] = xCurReel;
    }

    private void DisableNewReelControls()
    {
      List<Control> xNewReelControls = new List<Control>()
      {
        this.txtCurFeedSpacing,
        this.txtCurHeight,
        this.txtCurManufacturer,
        this.txtCurOrderCode,
        this.txtCurSupplier,
        this.txtCurXOffset,
        this.txtCurYOffset,
        this.comCurNozzle,
        this.comCurPackageType,
        this.comCurSpeed
      };
      foreach (Control xCtrl in xNewReelControls)
        xCtrl.Enabled = false;
    }

    private void LoadNewReelSettings()
    {
      if (_iCurrentItem == -1)
        return;

      // retrieve the reel info object that holds the data for this entry:
      //int iCur = (int)this.listMissingReels.SelectedItems[0].Tag;
      AutomaticReelConfig();
      NewReelInfo xCurEntry = _xNewReelList[_iCurrentItem];

      // enable appropriate controls:
      this.rdbReplacePart.Checked = false;
      this.rdbAddNew.Checked = false;
      this.rdbExclude.Checked = false;
      //DisableNewReelControls();

      switch (xCurEntry.Solution)
      {
        case MissingReelSolution.StandIn:
          this.rdbReplacePart.Checked = true;
          //this.comCurReplace.Enabled = true;
          break;

        case MissingReelSolution.NewReel:
          this.rdbAddNew.Checked = true;
          //this.txtCurFeedSpacing.Enabled = true;
          //this.txtCurHeight.Enabled = true;
          //this.txtCurManufacturer.Enabled = true;
          //this.txtCurOrderCode.Enabled = true;
          //this.txtCurSupplier.Enabled = true;
          //this.txtCurXOffset.Enabled = true;
          //this.txtCurYOffset.Enabled = true;
          //this.comCurNozzle.Enabled = true;
          //this.comCurPackageType.Enabled = true;
          //this.comCurSpeed.Enabled = true;
          break;

        case MissingReelSolution.Exclude:
          this.rdbExclude.Checked = true;
          break;
      }

      this.txtCurManufacturer.Text = xCurEntry.Manufacturer;
      this.txtCurOrderCode.Text = xCurEntry.OrderCode;
      this.txtCurSupplier.Text = xCurEntry.Supplier;
      this.txtCurXOffset.Text = xCurEntry.XOffset.ToString();
      this.txtCurYOffset.Text = xCurEntry.YOffset.ToString();
      this.txtCurHeight.Text = xCurEntry.Footprint.Height.ToString();
      this.lblCurGUID.Text = "Unique reel ID: " + xCurEntry.GUID.ToString();

      // debug
      if (this.rdbReplacePart.Checked)
        this.comCurReplace.SelectedIndex = -1;
      
      switch (xCurEntry.Nozzle)
      {
        case PnPMachineNozzle.L:
          this.comCurNozzle.SelectedIndex = 0;
          break;
        case PnPMachineNozzle.M:
          this.comCurNozzle.SelectedIndex = 1;
          break;
        case PnPMachineNozzle.S:
          this.comCurNozzle.SelectedIndex = 2;
          break;
        case PnPMachineNozzle.XS:
          this.comCurNozzle.SelectedIndex = 3;
          break;
        case PnPMachineNozzle.Undefined:
          this.comCurNozzle.SelectedIndex = -1;
          break;
      }

      switch (xCurEntry.PackageType)
      {
        case PnPSupplyPackage.Reel8mm:
          this.comCurPackageType.SelectedIndex = 0;
          break;
        case PnPSupplyPackage.Reel12mm:
          this.comCurPackageType.SelectedIndex = 1;
          break;
        case PnPSupplyPackage.Reel16mm:
          this.comCurPackageType.SelectedIndex = 2;
          break;
        case PnPSupplyPackage.Tray:
          this.comCurPackageType.SelectedIndex = 3;
          break;
        case PnPSupplyPackage.Tube:
          this.comCurPackageType.SelectedIndex = 4;
          break;
        case PnPSupplyPackage.Undefined:
          this.comCurPackageType.SelectedIndex = -1;
          break;  
      }

      if (xCurEntry.Speed > 90)
        this.comCurSpeed.SelectedIndex = 0;
      else if (xCurEntry.Speed < 90 && xCurEntry.Speed >= 70)
        this.comCurSpeed.SelectedIndex = 1;
      else if (xCurEntry.Speed < 70 && xCurEntry.Speed >= 40)
        this.comCurSpeed.SelectedIndex = 2;
      else if (xCurEntry.Speed < 40 && xCurEntry.Speed > 10)
        this.comCurSpeed.SelectedIndex = 3;
      else if (xCurEntry.Speed <= 10)
        this.comCurSpeed.SelectedIndex = 4;
      else
        this.comCurSpeed.SelectedIndex = -1;

      // search the entry in the combobox that matches the replacment GUID and select it
      if (!xCurEntry.ReplacementReel.Equals(Guid.Empty))
      {
        int iReelIndex = -1;
        for (int iCur = 0; iCur < this.comCurReplace.Items.Count; iCur++)
        {
          object xItem = this.comCurReplace.Items[iCur];
          if (xItem.ToString().EndsWith("[" + xCurEntry.ReplacementReel.ToString() + "]"))
            iReelIndex = iCur;  
        }
        this.comCurReplace.SelectedIndex = iReelIndex;
      }
      

    }

    private void ConfigureReel(object sender, EventArgs e)
    {
      // DEBUG

      if (this.listMissingReels.SelectedItems.Count == 0)
      {
        //StoreNewReelSettings();
        //this.lblMissingReels.Text = "None selected!";
      }
      else
      {
        // store settings at old index:
        StoreNewReelSettings();
        if (_iCurrentItem != -1)
        {
          bool bValidity = CheckSolution();
          if (bValidity)
            this.listMissingReels.Items[_iCurrentItem].ImageIndex = 0;
          else
            this.listMissingReels.Items[_iCurrentItem].ImageIndex = 1;

          NewReelInfo xReel = _xNewReelList[_iCurrentItem];
          xReel.DataOK = bValidity;
          _xNewReelList[_iCurrentItem] = xReel;
        }
        
        // switch index to new item:
        _iCurrentItem = (int)this.listMissingReels.SelectedItems[0].Tag;
        this.lblMissingReels.Text = "Selected index: " + this.listMissingReels.SelectedItems[0].ToString();

        // load settings at new index:
        LoadNewReelSettings();

        // check if the Next button can be enabled if all data is correct:
        bool bDataValid = true;
        foreach (NewReelInfo xCurReel in _xNewReelList)
          if (!xCurReel.DataOK)
            bDataValid = false;
        this.btnNext.Enabled = bDataValid;
      }



      //MessageBox.Show("Selected item: " + this.listMissingReels.SelectedItems[0].Text);
    }

    private void ChangeSolution(object sender, EventArgs e)
    {
      DisableNewReelControls();
      if (rdbAddNew.Checked)
      {
        this.txtCurFeedSpacing.Enabled = true;
        this.txtCurHeight.Enabled = true;
        this.txtCurManufacturer.Enabled = true;
        this.txtCurOrderCode.Enabled = true;
        this.txtCurSupplier.Enabled = true;
        this.txtCurXOffset.Enabled = true;
        this.txtCurYOffset.Enabled = true;
        this.comCurNozzle.Enabled = true;
        this.comCurPackageType.Enabled = true;
        this.comCurSpeed.Enabled = true;
      }
      else if (rdbReplacePart.Checked)
      {
        this.comCurReplace.Enabled = true;
      }
      else if (rdbExclude.Checked)
      {
        // nothing needs to be enabled here
      }
    }

    public bool CheckSolution()
    {
      if (_iCurrentItem == -1)
        return false;

      bool bState = false;
      if (this.rdbReplacePart.Checked)
      {
        bState = (this.comCurReplace.SelectedIndex > -1);
      }
      else if (this.rdbAddNew.Checked)
      {
        bState = true;
        if (this.txtCurManufacturer.Text.Trim() == string.Empty)
          bState = false;
      
        if (this.txtCurSupplier.Text.Trim() == string.Empty)
          bState = false;

        if (this.comCurPackageType.SelectedIndex == -1)
          bState = false;

        if (this.comCurNozzle.SelectedIndex == -1)
          bState = false;

        if (this.comCurSpeed.SelectedIndex == -1)
          bState = false;

        int iFS = -1;
        if (!int.TryParse(this.txtCurFeedSpacing.Text, out iFS))
          bState = false;
        else
          if (iFS <= 0)
            bState = false;
      }
      else if (this.rdbExclude.Checked)
      {
        bState = true;
      }
      else
      {
        bState = false;
      }
      return bState;
    }

    private string _sProjectName = string.Empty;
    private int _PCBCount = -1;

    private void LoadProjectName()
    {
      if (_sProjectName == string.Empty)
      {
        const string FN_LEAD = "Pick Place for ";
        if (_xPnPFile.Name.StartsWith(FN_LEAD))
        {
          _sProjectName = _xPnPFile.Name.Substring(FN_LEAD.Length);
          _sProjectName = _sProjectName.Substring(0, _sProjectName.Length - _xPnPFile.Extension.Length);
        }
        else
        {
          _sProjectName = _xPnPFile.Name;
        }
      }
      this.txtProjectName.Text = _sProjectName;

      if (_PCBCount == -1)
        _PCBCount = 1;
      this.numPCBCount.Value = _PCBCount;
    }

    private void SaveNewReels()
    {
      // if the user has provided new reel data, then add these reels to the library:
      bool bNewReelsAdded = false;
      foreach (NewReelInfo xNewReel in _xNewReelList)
      {
        if (xNewReel.Solution == MissingReelSolution.NewReel)
        {
          PnPReel xReel = new PnPReel();
          // copy relevant properties
          xReel.GUID = xNewReel.GUID;
          xReel.PartNumberOrValue = xNewReel.PartNameOrValue;
          xReel.Manufacturer = xNewReel.Manufacturer;
          xReel.Supplier = xNewReel.Supplier;
          xReel.OrderCode = xNewReel.OrderCode;
          xReel.SupplyPackage = xNewReel.PackageType;
          xReel.Footprint = xNewReel.Footprint;
          xReel.FeedSpacing = xNewReel.FeedSpacing;
          xReel.Nozzle = xNewReel.Nozzle;
          xReel.XOffset = xNewReel.XOffset;
          xReel.YOffset = xNewReel.YOffset;
          xReel.Speed = xNewReel.Speed;

          // add this reel to the collection:
          _xReelLibrary.Add(xReel);
          bNewReelsAdded = true;

          // experimental
          // assign the newly created Reel to the associated Parts
          for (int iCur = 0; iCur < _xPartsList.Count; iCur++)
          {
            PnPPart xCurPart = _xPartsList[iCur];
            if (xNewReel.Designators.Contains(xCurPart.Designator))
              xCurPart.AssignedReel = xNewReel.GUID;
          }
        }
        // experimental
        else if (xNewReel.Solution == MissingReelSolution.StandIn)
        {
          // assign the selected Reel to replace the actual one to the associated Parts
          for (int iCur = 0; iCur < _xPartsList.Count; iCur++)
          {
            PnPPart xCurPart = _xPartsList[iCur];
            if (xNewReel.Designators.Contains(xCurPart.Designator))
              xCurPart.AssignedReel = xNewReel.ReplacementReel;
          }
        }
      }

      // save the library to disk:
      if (bNewReelsAdded)
        PnPReel.SaveReels(_xReelLibrary);
    }

    /// <summary>
    /// List of Reels for all Parts in this project.
    /// </summary>
    List<PnPReel> _xActiveReels = new List<PnPReel>();

    /// <summary>
    /// List of Stacks for all Phases in this project.
    /// </summary>
    List<PnPStack> _xActiveStacks = new List<PnPStack>();

    /// <summary>
    /// The Pick and Place Machine for which the current project will generate files.
    /// </summary>
    PnPMachine _xMachine = new TM220A();

    private void GeneratePhases()
    {
      // erase existing data of active reels and stacks:
      _xActiveReels.Clear();
      _xActiveStacks.Clear();
      
      // assemble a list of Reels required in this project:
      //foreach (PnPPart xCurPart in _xPartsList)
      //{
      //  // add the Reel for this part to the active Reel list if it hasn't been added yet:
      //  for (int iCur = 0; iCur < _xReelLibrary.Count; iCur++)
      //  {
      //    PnPReel xCurReel = _xReelLibrary[iCur];
      //    if (xCurReel.Footprint.Equals(xCurPart.Footprint) && xCurReel.PartNumberOrValue == xCurPart.PartNumberOrValue)
      //      if (_xActiveReels.IndexOf(xCurReel) == -1)
      //      {
      //        xCurReel.StackAssigned = false;
      //        _xActiveReels.Add(xCurReel);
      //      }
      //  }
      //}
      foreach (PnPPart xCurPart in _xPartsList)
      {
        // if the user selected a Part to be placed manually, it will not have a Reel assigned to it
        if (xCurPart.AssignedReel != Guid.Empty)
        {
          // search the matching Reel for this Part
          PnPReel xReel = null;
          foreach (PnPReel xMatchReel in _xReelLibrary)
            if (xMatchReel.GUID == xCurPart.AssignedReel)
            {
              xReel = xMatchReel;
              break;
            }

          // check if no such Reel has been added yet to the list of active Reels:
          if (_xActiveReels.IndexOf(xReel) == -1)
          {
            // add Reel to the list of active Reels:
            xReel.StackAssigned = false;
            _xActiveReels.Add(xReel);
          }
        }
      }

      // first identify the Reels that are currently loaded into the Machine and can be used, and assign them to Phase 1:
      for (int iCur = 0; iCur < _xActiveReels.Count; iCur++)
      {
        PnPReel xCurReel = _xActiveReels[iCur];
        foreach (PnPStack xCurStack in _xMachine.GetStacks(PnPStackType.Undefined))
        {
          if (xCurStack.Reel.Equals(xCurReel))
          {
            PnPStack xNewStack = new PnPStack(xCurStack.Location, xCurStack.MaxHeight);
            xNewStack.Phase = 1;
            _xActiveStacks.Add(xNewStack); 
            xCurReel.StackAssigned = true;
          }
        }
      }

      // also identify the locked Stacks and add them to the Stack list to prevent them from being reused
      foreach (PnPStack xCurStack in _xMachine.GetStacks(PnPStackType.Undefined))
        if (xCurStack.Locked)
        {
          PnPStack xLockedStack = xCurStack;
          xLockedStack.Phase = 1;
          _xActiveStacks.Add(xLockedStack);
        }

      // count the number of Reels that do not yet have a Stack assigned:
      int iStacklessReels = 0;
      foreach (PnPReel xCurReel in _xActiveReels)
        if (!xCurReel.StackAssigned)      
          iStacklessReels++;

      int iPhase = 1; // the current phase to fill up
      // loop through the Reels in the active project until all have a Stack assigned to them:
      while (iStacklessReels > 0)
      {
        
        // start by filling up 8 mm stacks:
        //PnPMachine damachine = new TM220A();
        int iStacks8mm = _xMachine.GetStacks(PnPStackType.Reel8mm).Count;
        StackLocation xLoc = new StackLocation();
        xLoc.StackType = PnPStackType.Reel8mm;
        for (int i = 1; i <= iStacks8mm; i++)
        {
          // search in the stack list if the stack with the current Position is still available in the current Phase:
          bool bAvailable = true;
          xLoc.Position = i;
          foreach (PnPStack xCurStack in _xActiveStacks)
          {
            // break out of the search if the Stack on the current Location has been loaded in the current Phase:
            if (xCurStack.Phase == iPhase && xCurStack.Location.Equals(xLoc))
            {
              bAvailable = false;
              break;
            }

            // also break out of the search if the Stack on the current Location is marked as Locked, regardless of Phase:
            if (xCurStack.Phase == 1 && xCurStack.Location.Equals(xLoc) && xCurStack.Locked)
            {
              bAvailable = false;
              break;
            }
          }

          // if this Stack is available, assign a matching Reel in the Reel list to it:
          if (bAvailable)
          {
            // search a Reel that can be loaded in this Stack:
            //bool bReelFound = false;
            for (int iCur = 0; iCur < _xActiveReels.Count; iCur++)
            {
              PnPReel xCurReel = _xActiveReels[iCur];
              if (xCurReel.SupplyPackage == PnPSupplyPackage.Reel8mm && !xCurReel.StackAssigned && _xMachine.GetStack(xLoc).MaxHeight >= xCurReel.Footprint.Height)
              {
                xCurReel.StackAssigned = true;
                //_xActiveReels[iCur].StackAssigned = true;
                PnPStack xNewStack = new PnPStack(xLoc, _xMachine.GetStack(xLoc).MaxHeight);
                //xNewStack.Location = xLoc;
                xNewStack.LoadReel(xCurReel);
                xNewStack.Phase = iPhase;
                _xActiveStacks.Add(xNewStack);
                _xActiveReels[iCur] = xCurReel;
                //bReelFound = true;
                break;
              }
  
            // if no more reels need to be 
            //if (!bReelFound)
              //break;
            }
          }
        }


        // then fill up 12 mm stacks:
        int iStacks12mm = _xMachine.GetStacks(PnPStackType.Reel12mm).Count;
        xLoc = new StackLocation();
        xLoc.StackType = PnPStackType.Reel12mm;
        for (int i = 1; i <= iStacks12mm; i++)
        {
          // search in the stack list if the stack with the current Position is still available in the current Phase:
          bool bAvailable = true;
          xLoc.Position = i;
          foreach (PnPStack xCurStack in _xActiveStacks)
          {
            if (xCurStack.Phase == iPhase && xCurStack.Location.Equals(xLoc))
            {
              bAvailable = false;
              break;
            }

            // also break out of the search if the Stack on the current Location is marked as Locked, regardless of Phase:
            if (xCurStack.Phase == 1 && xCurStack.Location.Equals(xLoc) && xCurStack.Locked)
            {
              bAvailable = false;
              break;
            }
          }

          // if this Stack is available, assign a matching Reel in the Reel list to it:
          if (bAvailable)
          {
            // search a Reel that can be loaded in this Stack:
            //bool bReelFound = false;
            for (int iCur = 0; iCur < _xActiveReels.Count; iCur++)
            {
              PnPReel xCurReel = _xActiveReels[iCur];
              if (xCurReel.SupplyPackage == PnPSupplyPackage.Reel12mm && !xCurReel.StackAssigned && _xMachine.GetStack(xLoc).MaxHeight >= xCurReel.Footprint.Height)
              {
                xCurReel.StackAssigned = true;
                //_xActiveReels[iCur].StackAssigned = true;
                PnPStack xNewStack = new PnPStack(xLoc, _xMachine.GetStack(xLoc).MaxHeight);
                //xNewStack.Location = xLoc;
                xNewStack.LoadReel(xCurReel);
                xNewStack.Phase = iPhase;
                _xActiveStacks.Add(xNewStack);
                _xActiveReels[iCur] = xCurReel;
                //bReelFound = true;
                break;
              }

              // if no more reels need to be 
              //if (!bReelFound)
              //  break;
            }
          }
        }

        // then fill up 16 mm stacks:
        int iStacks16mm = _xMachine.GetStacks(PnPStackType.Reel16mm).Count;
        xLoc = new StackLocation();
        xLoc.StackType = PnPStackType.Reel16mm;
        for (int i = 1; i <= iStacks16mm; i++)
        {
          // search in the stack list if the stack with the current Position is still available in the current Phase:
          bool bAvailable = true;
          xLoc.Position = i;
          foreach (PnPStack xCurStack in _xActiveStacks)
          {
            if (xCurStack.Phase == iPhase && xCurStack.Location.Equals(xLoc))
            {
              bAvailable = false;
              break;
            }

            // also break out of the search if the Stack on the current Location is marked as Locked, regardless of Phase:
            if (xCurStack.Phase == 1 && xCurStack.Location.Equals(xLoc) && xCurStack.Locked)
            {
              bAvailable = false;
              break;
            }
          }

          // if this Stack is available, assign a matching Reel in the Reel list to it:
          if (bAvailable)
          {
            // search a Reel that can be loaded in this Stack:
            //bool bReelFound = false;
            for (int iCur = 0; iCur < _xActiveReels.Count; iCur++)
            {
              PnPReel xCurReel = _xActiveReels[iCur];
              if (xCurReel.SupplyPackage == PnPSupplyPackage.Reel16mm && !xCurReel.StackAssigned && _xMachine.GetStack(xLoc).MaxHeight >= xCurReel.Footprint.Height)
              {
                xCurReel.StackAssigned = true;
                //_xActiveReels[iCur].StackAssigned = true;
                PnPStack xNewStack = new PnPStack(xLoc, _xMachine.GetStack(xLoc).MaxHeight);
                //xNewStack.Location = xLoc;
                xNewStack.LoadReel(xCurReel);
                xNewStack.Phase = iPhase;
                _xActiveStacks.Add(xNewStack);
                _xActiveReels[iCur] = xCurReel;
                //bReelFound = true;
                break;
              }

              // if no more reels need to be 
              //if (!bReelFound)
              //  break;
            }
          }
        }

        // finally fill up 16 mm trays:
        int iTrays16mm = _xMachine.GetStacks(PnPStackType.Tray16mm).Count;
        xLoc = new StackLocation();
        xLoc.StackType = PnPStackType.Tray16mm;
        for (int i = 1; i <= iTrays16mm; i++)
        {
          // search in the stack list if the stack with the current Position is still available in the current Phase:
          bool bAvailable = true;
          xLoc.Position = i;
          foreach (PnPStack xCurStack in _xActiveStacks)
          {
            if (xCurStack.Phase == iPhase && xCurStack.Location.Equals(xLoc))
            {
              bAvailable = false;
              break;
            }

            // also break out of the search if the Stack on the current Location is marked as Locked, regardless of Phase:
            if (xCurStack.Phase == 1 && xCurStack.Location.Equals(xLoc) && xCurStack.Locked)
            {
              bAvailable = false;
              break;
            }
          }

          // if this Stack is available, assign a matching Reel in the Reel list to it:
          if (bAvailable)
          {
            // search a Reel that can be loaded in this Stack:
            //bool bReelFound = false;
            for (int iCur = 0; iCur < _xActiveReels.Count; iCur++)
            {
              PnPReel xCurReel = _xActiveReels[iCur];
              if ((xCurReel.SupplyPackage == PnPSupplyPackage.Tray || xCurReel.SupplyPackage == PnPSupplyPackage.Tube) && !xCurReel.StackAssigned)
              {
                //xCurReel.StackAssigned = true;
                //_xActiveReels[iCur].StackAssigned = true;
                PnPStack xNewStack = new PnPStack(xLoc, _xMachine.GetStack(xLoc).MaxHeight);
                //xNewStack.Location = xLoc;
                xNewStack.LoadReel(xCurReel);
                xNewStack.Phase = iPhase;
                _xActiveStacks.Add(xNewStack);
                xCurReel.StackAssigned = true;
                _xActiveReels[iCur] = xCurReel;
                //bReelFound = true;
                break;
              }

              // if no more reels need to be 
              //if (!bReelFound)
              //  break;
            }
          }
        }

        // (re)count the number of Reels that do not yet have a Stack assigned:
        iStacklessReels = 0;
        foreach (PnPReel xCurReel in _xActiveReels)
          if (!xCurReel.StackAssigned)
            iStacklessReels++;

        // add a new phase if not all Reels could be placed
        iPhase++;
      }

    }

    /// <summary>
    /// Configures the Tab control on the Phase panel to match the different Phases, and loads the Reels.
    /// </summary>
    private void DisplayPhases()
    {
      // first determine how many different Phases this project requires:
      int iPhaseCount = 1;
      foreach (PnPStack xPhaseStack in _xActiveStacks)
        if (xPhaseStack.Phase > iPhaseCount)
          iPhaseCount = xPhaseStack.Phase;

      // now add the necessary tabs to the Tab control:
      this.tabPhases.TabPages.Clear();
      for (int iPhase = 1; iPhase <= iPhaseCount; iPhase++)
      {
        TabPage xNewPage = new TabPage("Phase " + iPhase.ToString());
        xNewPage.Name = iPhase.ToString();
        xNewPage.AutoScroll = true;
        this.tabPhases.TabPages.Add(xNewPage);
      }


      //StackType[] xStackTypes = new StackType[] {StackType.Reel8mm, StackType.Reel12mm, StackType.Reel16mm, StackType.Tray16mm};
      //foreach (StackType xCurType in _xMachine.GetStackTypes())
      //{
      //  MessageBox.Show(xCurType.ToString());

      //}


      foreach (TabPage xCurPage in this.tabPhases.TabPages)
      {
        // clean up all controls on this tab page and clear the list:
        foreach (Control xControl in xCurPage.Controls)
          xControl.Dispose();
        xCurPage.Controls.Clear();

        int iRowCounter = 0;
        foreach (PnPStackType xCurType in _xMachine.GetStackTypes())
        {
          int iRows = _xMachine.GetStacks(xCurType).Count;
          
          for (int i = 1; i <= iRows; i++)
          {
            // create a checkbox to lock or unlock the Stack:
            StackLoader xStackLoader = new StackLoader();
            xStackLoader.Name = "stack" + i.ToString();
            xStackLoader.StackPosition = i;
            xStackLoader.Type = xCurType;
            xStackLoader.Location = new Point(10, 5 + iRowCounter * 28);
            xStackLoader.LockedStateChanged += new StackLoader.LockedStateChangedEventHandler(LockedReel);
            xStackLoader.SelectedReelChanged += new StackLoader.SelectedReelChangedEventHandler(ReelChanged);
            xStackLoader.Machine = _xMachine;     // first assign a machine before adding reels!       
            xStackLoader.Reels = _xReelLibrary;
            xStackLoader.ActiveReels = _xActiveReels;
            xStackLoader.Clear(); //removes any selection
            xCurPage.Controls.Add(xStackLoader);
            
            iRowCounter++;
          }
        }
      }

      //MessageBox.Show("pause");

      // fill every tab with the necessary controls:
      //foreach (TabPage xCurPage in this.tabPhases.TabPages)
      //{
      //  //PnPMachine xMachine = new TM220A();
      //  int iRows = _xMachine.GetStacks(StackType.Undefined).Count; // retrieve the number of stacks for this machine
        
      //  // clean up all controls on this tab page and clear the list:
      //  foreach (Control xControl in xCurPage.Controls)
      //    xControl.Dispose();
      //  xCurPage.Controls.Clear();

      //  for (int i = 1; i <= iRows; i++)
      //  {
      //    // create a checkbox to lock or unlock the Stack:
      //    StackLoader xStackLoader = new StackLoader();
      //    xStackLoader.Name = "stack" + i.ToString();
      //    //xStackLoader.Tag = i;

      //    xStackLoader.Location = new Point(10, 5 + i * 28);
      //    xStackLoader.LockedStateChanged += new StackLoader.LockedStateChangedEventHandler(LockedReel);
      //    xStackLoader.Reels = _xReelLibrary;
      //    xStackLoader.ActiveReels = _xActiveReels;
      //    xStackLoader.Clear(); //removes any selection
      //    xCurPage.Controls.Add(xStackLoader);
      //  }
      //}

      // load Reels in the Stacks
      foreach (PnPStack xActiveStack in _xActiveStacks)
      {
        // search the tab page for this phase:
        TabPage xPage = new TabPage();
        foreach (TabPage xCurPage in this.tabPhases.TabPages)
          if (xCurPage.Name == xActiveStack.Phase.ToString())
          {
            xPage = xCurPage;
            break;
          }

        // configure the Stack to the correct StackLoader on this page:
        foreach (Control xLoader in xPage.Controls)
        {
          StackLoader xStackLoader = (StackLoader)xLoader;

          if (xStackLoader.StackPosition == xActiveStack.Location.Position && xStackLoader.Type == xActiveStack.Location.StackType)
          {
            xStackLoader.Stack = xActiveStack;
          }
          
          
          // calculate the index of this Stack in the machine's Stack list:
          //int iLoaderIndex = xActiveStack.Location.Position;
          //switch (xActiveStack.Location.StackType)
          //{
          //  case StackType.Reel8mm:
          //    if ((int)xStackLoader.Tag == iLoaderIndex)
          //      xStackLoader.Stack = xActiveStack;
          //    else
          //    {
          //      StackLocation xLoc = new StackLocation();
          //      xLoc.StackType = StackType.Reel8mm;
          //      xLoc.Position = (int)xStackLoader.Tag;
          //      xStackLoader.Stack = new PnPStack(xLoc, 5); // verify 5  
          //      xStackLoader.Clear();
          //    }
          //    break;               
          //  //  break;
          //  case StackType.Reel12mm:
          //    if ((int)xStackLoader.Tag + _xMachine.GetStacks(StackType.Reel8mm).Count == iLoaderIndex)
          //      xStackLoader.Stack = xActiveStack;
          //    //iLoaderIndex += _xMachine.GetStacks(StackType.Reel8mm);
          //    break;
          //  case StackType.Reel16mm:
          //    if ((int)xStackLoader.Tag + _xMachine.GetStacks(StackType.Reel8mm).Count + _xMachine.GetStacks(StackType.Reel12mm).Count == iLoaderIndex)
          //      xStackLoader.Stack = xActiveStack;
          //    //iLoaderIndex += _xMachine.GetStacks(StackType.Reel8mm) + _xMachine.GetStacks(StackType.Reel12mm);
          //    break;
          //  case StackType.Tray16mm:
          //    if ((int)xStackLoader.Tag + _xMachine.GetStacks(StackType.Reel8mm).Count + _xMachine.GetStacks(StackType.Reel12mm).Count + _xMachine.GetStacks(StackType.Reel16mm).Count == iLoaderIndex)
          //      xStackLoader.Stack = xActiveStack;
          //    //iLoaderIndex += _xMachine.GetStacks(StackType.Reel8mm) + _xMachine.GetStacks(StackType.Reel12mm) + _xMachine.GetStacks(StackType.Reel16mm);
          //    break;
          //}
          
        }

      }

    }

    private void LockedReel(object sender, EventArgs e)
    {
      //MessageBox.Show("locked state changed!");
      
      // lock or unlock this row in all other tabs, too
      StackLoader xLoader = (StackLoader)sender;
      foreach (TabPage xCurTab in this.tabPhases.TabPages)
      {
        foreach (Control xCurCtrl in xCurTab.Controls)
        {
          StackLoader xCurLoader = (StackLoader)xCurCtrl;
          // lock or unlock only stacks on other tab pages:
          if (!xCurLoader.Equals(xLoader))
          {
            if (xCurLoader.StackPosition == xLoader.StackPosition && xCurLoader.Type == xLoader.Type)
              xCurLoader.Locked = xLoader.Locked;
          }
        }
      }
    }

    private void ReelChanged(object sender, EventArgs e)
    {
      CheckReelConfiguration();
      //MessageBox.Show("fired!");
      this.lblUnassignedReels.Refresh();
    }

    private int CheckReelConfiguration()
    {
      // to verify the configuration, check that every reel has been placed in a slot:
      int iReelsFound = 0;

      foreach (TabPage xCurPage in this.tabPhases.TabPages)
      {
        foreach (PnPReel xReel in _xActiveReels)
        {
          bool bReelFound = false;
          foreach (Control xCurControl in xCurPage.Controls)
          {
            StackLoader xCurLoader = (StackLoader)xCurControl;
            if (!xCurLoader.IsEmpty)
            {
              if (xReel.Equals(xCurLoader.SelectedReel))
              {
                bReelFound = true;
                break;
              }
            }
          }
          if (bReelFound)
            iReelsFound++;
        }
      }

      int iUnassigned = _xActiveReels.Count - iReelsFound;
      this.lblUnassignedReels.Text = "Unassigned reels: " + iUnassigned.ToString();
      return iUnassigned;
    }

    private void CheckReelConfigurationButton(object sender, EventArgs e)
    {
      CheckReelConfiguration();      
    }

    /// <summary>
    /// Updates _xActiveStacks with the configuration that the user selected in the GUI
    /// </summary>
    private void UpdateStackConfiguration()
    {
      //List<PnPReel> xTempReels = new List<PnPReel>();
      foreach (TabPage xCurPage in this.tabPhases.TabPages)
      { 
        foreach (Control xCurLoader in xCurPage.Controls)
        {
          StackLoader xLoader = (StackLoader)xCurLoader;
          
          if (xLoader.IsEmpty)
          {
            PnPStack xMatchStack = null;
            foreach (PnPStack xCurStack in _xActiveStacks)
              if (xCurStack.Location.Position == xLoader.StackPosition && xCurStack.Location.StackType == xLoader.Type && xCurPage.Name == xCurStack.Phase.ToString())
              {
                xMatchStack = xCurStack;
                break;
              }
            if (xMatchStack != null)
              _xActiveStacks.Remove(xMatchStack);
          }
          else
          {
            // search any currently matching stack:
            bool bStackFound = false;
            for (int iCur = 0; iCur < _xActiveStacks.Count; iCur++)
            {
              PnPStack xCurStack = _xActiveStacks[iCur];

              // check if the current Stack matches the one in this StackLoader
              if (xCurStack.Location.Position == xLoader.StackPosition && xCurStack.Location.StackType == xLoader.Type && xCurPage.Name == xCurStack.Phase.ToString())
              {
                xCurStack.LoadReel(xLoader.SelectedReel);
                //if (_xActiveReels.IndexOf(xLoader.SelectedReel) == -1)
                //  _xActiveReels.Add(xLoader.SelectedReel);
                bStackFound = true;
                break;
              }
            }

            // if selected Reel is not yet in the list of active Stacks, add it
            if (!bStackFound)
            {
              StackLocation xLoc = new StackLocation();
              xLoc.Position = xLoader.StackPosition;
              xLoc.StackType = xLoader.Type;
              PnPStack xNewStack = new PnPStack(xLoc, _xMachine.GetStack(xLoc).MaxHeight);
              xNewStack.LoadReel(xLoader.SelectedReel);
              int iNewPhase;
              int.TryParse(xCurPage.Name, out iNewPhase); // retrieve the phase from the tab page
              xNewStack.Phase = iNewPhase;
              _xActiveStacks.Add(xNewStack);
              xLoader.SelectedReel.StackAssigned = true;
              _xActiveReels.Add(xLoader.SelectedReel);
            }

            // add this reel to the list of active reels if it's not part of it yet
            //if (xTempReels.IndexOf(xLoader.SelectedReel) != -1)
            //  xTempReels.Add(xLoader.SelectedReel);
          }
        }
      }
      //_xActiveReels = xTempReels;

     
    }

    private void ExportFiles()
    {
      // count the phases:
      int iPhases = 0;
      foreach (PnPStack xCurStack in _xActiveStacks)
        if (xCurStack.Phase > iPhases)
          iPhases = xCurStack.Phase;

      int iMissingReels = CheckReelConfiguration();
      if (iMissingReels > 0) // reels missing
      {
        string sMsg = string.Empty;
        string sTitle = string.Empty;
        if (iMissingReels == 1)
        {
          sMsg = "There is 1 reel"; 
          sTitle = "Missing reel";
        }
        else
        {
          sMsg = "There are " + iMissingReels.ToString() + " reels";
          sTitle = "Missing reels";
        }
        DialogResult xAns = MessageBox.Show(sMsg + " missing from the configuration to populate the board. Would you like to exclude the associated part(s) from automatic placement and continue exporting production files?", sTitle, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
        if (xAns != DialogResult.Yes)
          return;
      }
      else
      {
        DialogResult xResponse = MessageBox.Show("Export " + iPhases.ToString() + " phase(s) to production files?", "Export", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
        if (xResponse != DialogResult.Yes)
          return;
      }

      _xMachine.ExportPnPData(_xPnPFile.Directory, _sProjectName, _xActiveStacks, _xPartsList);
      //_xMachine.ExportPnPData(new FileInfo("file"), _xActiveStacks);



    }

    /// <summary>
    /// Checks the part list for parts that do not have a reel assigned to them, and exclude them from the active aprts list.
    /// </summary>
    private void RemoveReellessParts()
    {
      List<PnPPart>xReellessParts = new List<PnPPart>();
      foreach (PnPPart xCurPart in _xPartsList)
      {
        bool bReelfound = false;
        foreach (PnPReel xCurReel in _xActiveReels)
          if (xCurReel.GUID == xCurPart.AssignedReel)
            bReelfound = true;

        if (!bReelfound)
          xReellessParts.Add(xCurPart);
      }

      for (int iCur = 0; iCur < xReellessParts.Count; iCur++)
      {
        PnPPart xCurPart = xReellessParts[iCur];
        _xPartsList.Remove(xCurPart);
        xCurPart.AssignedReel = Guid.Empty;
        xCurPart.ExclusionReason = ExclusionReason.NoReelAssigned;
        _xExcludedPartsList.Add(xCurPart);
      }
    }
    
  }
}
