﻿namespace PnPConverter
{
  partial class NewProjectWizard
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "IC5",
            "IC-SOIC-20"}, -1);
      System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "K7",
            "CONN-SB-0.2"}, -1);
      System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("OK");
      System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "C17",
            "CAP-0805",
            "Capacitor, 0805",
            "100nF",
            "2mm"}, -1);
      this.btnCancel = new System.Windows.Forms.Button();
      this.btnNext = new System.Windows.Forms.Button();
      this.btnBack = new System.Windows.Forms.Button();
      this.pnlIntro = new System.Windows.Forms.Panel();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.pnlSelectPnP = new System.Windows.Forms.Panel();
      this.picPnPOK = new System.Windows.Forms.PictureBox();
      this.picPnPNOK = new System.Windows.Forms.PictureBox();
      this.listPartPreview = new System.Windows.Forms.ListView();
      this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
      this.lblPartPreviewMessage = new System.Windows.Forms.Label();
      this.txtPnPFile = new System.Windows.Forms.TextBox();
      this.btnBrowsePnPFile = new System.Windows.Forms.Button();
      this.label3 = new System.Windows.Forms.Label();
      this.pnlSelectLib = new System.Windows.Forms.Panel();
      this.lblADLib = new System.Windows.Forms.Label();
      this.btnPurgeLibs = new System.Windows.Forms.Button();
      this.btnRemoveLib = new System.Windows.Forms.Button();
      this.listLibraries = new System.Windows.Forms.ListView();
      this.btnAddLib = new System.Windows.Forms.Button();
      this.lblFootprintCount = new System.Windows.Forms.Label();
      this.picLibNOK = new System.Windows.Forms.PictureBox();
      this.picLibOK = new System.Windows.Forms.PictureBox();
      this.pnlReviewParts = new System.Windows.Forms.Panel();
      this.btnOmitSelected = new System.Windows.Forms.Button();
      this.lnkOmittedParts = new System.Windows.Forms.LinkLabel();
      this.listPartSummary = new System.Windows.Forms.ListView();
      this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
      this.label6 = new System.Windows.Forms.Label();
      this.pnlAddReels = new System.Windows.Forms.Panel();
      this.lblMissingReels = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.tabNewReel = new System.Windows.Forms.TabControl();
      this.tabPage1 = new System.Windows.Forms.TabPage();
      this.txtCurManufacturer = new System.Windows.Forms.TextBox();
      this.lblCurManufacturer = new System.Windows.Forms.Label();
      this.lblSupply = new System.Windows.Forms.Label();
      this.comCurPackageType = new System.Windows.Forms.ComboBox();
      this.txtCurOrderCode = new System.Windows.Forms.TextBox();
      this.lblCurSupplier = new System.Windows.Forms.Label();
      this.lblCurOrderCode = new System.Windows.Forms.Label();
      this.txtCurSupplier = new System.Windows.Forms.TextBox();
      this.tabPage2 = new System.Windows.Forms.TabPage();
      this.comCurNozzle = new System.Windows.Forms.ComboBox();
      this.comCurSpeed = new System.Windows.Forms.ComboBox();
      this.label9 = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.txtCurFeedSpacing = new System.Windows.Forms.TextBox();
      this.label7 = new System.Windows.Forms.Label();
      this.txtCurYOffset = new System.Windows.Forms.TextBox();
      this.txtCurXOffset = new System.Windows.Forms.TextBox();
      this.lblMm = new System.Windows.Forms.Label();
      this.lblHeight = new System.Windows.Forms.Label();
      this.txtCurHeight = new System.Windows.Forms.TextBox();
      this.lblCurSpeed = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.lblCurFeedSpacing = new System.Windows.Forms.Label();
      this.lblCurNozzle = new System.Windows.Forms.Label();
      this.lblCurOffset = new System.Windows.Forms.Label();
      this.rdbExclude = new System.Windows.Forms.RadioButton();
      this.lblCurGUID = new System.Windows.Forms.Label();
      this.rdbAddNew = new System.Windows.Forms.RadioButton();
      this.comCurReplace = new System.Windows.Forms.ComboBox();
      this.rdbReplacePart = new System.Windows.Forms.RadioButton();
      this.listMissingReels = new System.Windows.Forms.ListView();
      this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader10 = new System.Windows.Forms.ColumnHeader();
      this.pnlProjectProperties = new System.Windows.Forms.Panel();
      this.lblBoards = new System.Windows.Forms.Label();
      this.numPCBCount = new System.Windows.Forms.NumericUpDown();
      this.txtProjectName = new System.Windows.Forms.TextBox();
      this.label5 = new System.Windows.Forms.Label();
      this.lblProjectName = new System.Windows.Forms.Label();
      this.pnlPhases = new System.Windows.Forms.Panel();
      this.lblUnassignedReels = new System.Windows.Forms.Label();
      this.btnReassignReels = new System.Windows.Forms.Button();
      this.tabPhases = new System.Windows.Forms.TabControl();
      this.button1 = new System.Windows.Forms.Button();
      this.pnlIntro.SuspendLayout();
      this.pnlSelectPnP.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.picPnPOK)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.picPnPNOK)).BeginInit();
      this.pnlSelectLib.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.picLibNOK)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.picLibOK)).BeginInit();
      this.pnlReviewParts.SuspendLayout();
      this.pnlAddReels.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.tabNewReel.SuspendLayout();
      this.tabPage1.SuspendLayout();
      this.tabPage2.SuspendLayout();
      this.pnlProjectProperties.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numPCBCount)).BeginInit();
      this.pnlPhases.SuspendLayout();
      this.SuspendLayout();
      // 
      // btnCancel
      // 
      this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.btnCancel.Location = new System.Drawing.Point(46, 185);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(75, 23);
      this.btnCancel.TabIndex = 0;
      this.btnCancel.Text = "&Cancel";
      this.btnCancel.UseVisualStyleBackColor = true;
      // 
      // btnNext
      // 
      this.btnNext.Location = new System.Drawing.Point(46, 156);
      this.btnNext.Name = "btnNext";
      this.btnNext.Size = new System.Drawing.Size(75, 23);
      this.btnNext.TabIndex = 1;
      this.btnNext.Text = "&Next";
      this.btnNext.UseVisualStyleBackColor = true;
      this.btnNext.Click += new System.EventHandler(this.NextStep);
      // 
      // btnBack
      // 
      this.btnBack.Enabled = false;
      this.btnBack.Location = new System.Drawing.Point(46, 127);
      this.btnBack.Name = "btnBack";
      this.btnBack.Size = new System.Drawing.Size(75, 23);
      this.btnBack.TabIndex = 2;
      this.btnBack.Text = "&Back";
      this.btnBack.UseVisualStyleBackColor = true;
      this.btnBack.Click += new System.EventHandler(this.PreviousStep);
      // 
      // pnlIntro
      // 
      this.pnlIntro.BackColor = System.Drawing.Color.Silver;
      this.pnlIntro.Controls.Add(this.label2);
      this.pnlIntro.Controls.Add(this.label1);
      this.pnlIntro.Location = new System.Drawing.Point(12, 12);
      this.pnlIntro.Name = "pnlIntro";
      this.pnlIntro.Size = new System.Drawing.Size(148, 106);
      this.pnlIntro.TabIndex = 3;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(12, 64);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(97, 13);
      this.label2.TabIndex = 1;
      this.label2.Text = "Export AD PnP file!";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(12, 14);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(32, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "hello!";
      // 
      // pnlSelectPnP
      // 
      this.pnlSelectPnP.BackColor = System.Drawing.Color.RosyBrown;
      this.pnlSelectPnP.Controls.Add(this.picPnPOK);
      this.pnlSelectPnP.Controls.Add(this.picPnPNOK);
      this.pnlSelectPnP.Controls.Add(this.listPartPreview);
      this.pnlSelectPnP.Controls.Add(this.lblPartPreviewMessage);
      this.pnlSelectPnP.Controls.Add(this.txtPnPFile);
      this.pnlSelectPnP.Controls.Add(this.btnBrowsePnPFile);
      this.pnlSelectPnP.Controls.Add(this.label3);
      this.pnlSelectPnP.Location = new System.Drawing.Point(171, 12);
      this.pnlSelectPnP.Name = "pnlSelectPnP";
      this.pnlSelectPnP.Size = new System.Drawing.Size(363, 268);
      this.pnlSelectPnP.TabIndex = 4;
      this.pnlSelectPnP.Visible = false;
      // 
      // picPnPOK
      // 
      this.picPnPOK.Image = global::PnPConverter.Properties.Resources.ok;
      this.picPnPOK.Location = new System.Drawing.Point(111, 207);
      this.picPnPOK.Name = "picPnPOK";
      this.picPnPOK.Size = new System.Drawing.Size(45, 45);
      this.picPnPOK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picPnPOK.TabIndex = 7;
      this.picPnPOK.TabStop = false;
      // 
      // picPnPNOK
      // 
      this.picPnPNOK.Image = global::PnPConverter.Properties.Resources.nok;
      this.picPnPNOK.Location = new System.Drawing.Point(56, 207);
      this.picPnPNOK.Name = "picPnPNOK";
      this.picPnPNOK.Size = new System.Drawing.Size(45, 45);
      this.picPnPNOK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picPnPNOK.TabIndex = 6;
      this.picPnPNOK.TabStop = false;
      // 
      // listPartPreview
      // 
      this.listPartPreview.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
      this.listPartPreview.FullRowSelect = true;
      listViewItem1.StateImageIndex = 0;
      listViewItem2.StateImageIndex = 0;
      this.listPartPreview.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2});
      this.listPartPreview.Location = new System.Drawing.Point(17, 131);
      this.listPartPreview.MultiSelect = false;
      this.listPartPreview.Name = "listPartPreview";
      this.listPartPreview.Size = new System.Drawing.Size(242, 70);
      this.listPartPreview.TabIndex = 5;
      this.listPartPreview.UseCompatibleStateImageBehavior = false;
      this.listPartPreview.View = System.Windows.Forms.View.Details;
      // 
      // columnHeader1
      // 
      this.columnHeader1.Text = "Designator";
      this.columnHeader1.Width = 88;
      // 
      // columnHeader2
      // 
      this.columnHeader2.Text = "Footprint";
      this.columnHeader2.Width = 84;
      // 
      // lblPartPreviewMessage
      // 
      this.lblPartPreviewMessage.AutoSize = true;
      this.lblPartPreviewMessage.Location = new System.Drawing.Point(106, 93);
      this.lblPartPreviewMessage.Name = "lblPartPreviewMessage";
      this.lblPartPreviewMessage.Size = new System.Drawing.Size(131, 13);
      this.lblPartPreviewMessage.TabIndex = 4;
      this.lblPartPreviewMessage.Text = "This is a valid AD PnP file!";
      // 
      // txtPnPFile
      // 
      this.txtPnPFile.Location = new System.Drawing.Point(17, 54);
      this.txtPnPFile.Name = "txtPnPFile";
      this.txtPnPFile.Size = new System.Drawing.Size(139, 20);
      this.txtPnPFile.TabIndex = 2;
      // 
      // btnBrowsePnPFile
      // 
      this.btnBrowsePnPFile.Location = new System.Drawing.Point(162, 54);
      this.btnBrowsePnPFile.Name = "btnBrowsePnPFile";
      this.btnBrowsePnPFile.Size = new System.Drawing.Size(75, 23);
      this.btnBrowsePnPFile.TabIndex = 1;
      this.btnBrowsePnPFile.Text = "Bro&wse";
      this.btnBrowsePnPFile.UseVisualStyleBackColor = true;
      this.btnBrowsePnPFile.Click += new System.EventHandler(this.BrowsePnPFile);
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(14, 14);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(82, 13);
      this.label3.TabIndex = 0;
      this.label3.Text = "Select PnP File:";
      // 
      // pnlSelectLib
      // 
      this.pnlSelectLib.BackColor = System.Drawing.Color.LightGreen;
      this.pnlSelectLib.Controls.Add(this.lblADLib);
      this.pnlSelectLib.Controls.Add(this.btnPurgeLibs);
      this.pnlSelectLib.Controls.Add(this.btnRemoveLib);
      this.pnlSelectLib.Controls.Add(this.listLibraries);
      this.pnlSelectLib.Controls.Add(this.btnAddLib);
      this.pnlSelectLib.Controls.Add(this.lblFootprintCount);
      this.pnlSelectLib.Controls.Add(this.picLibNOK);
      this.pnlSelectLib.Controls.Add(this.picLibOK);
      this.pnlSelectLib.Location = new System.Drawing.Point(540, 12);
      this.pnlSelectLib.Name = "pnlSelectLib";
      this.pnlSelectLib.Size = new System.Drawing.Size(322, 268);
      this.pnlSelectLib.TabIndex = 5;
      this.pnlSelectLib.Visible = false;
      // 
      // lblADLib
      // 
      this.lblADLib.AutoSize = true;
      this.lblADLib.Location = new System.Drawing.Point(156, 82);
      this.lblADLib.Name = "lblADLib";
      this.lblADLib.Size = new System.Drawing.Size(68, 13);
      this.lblADLib.TabIndex = 13;
      this.lblADLib.Text = "Valid AD Lib!";
      // 
      // btnPurgeLibs
      // 
      this.btnPurgeLibs.Location = new System.Drawing.Point(116, 218);
      this.btnPurgeLibs.Name = "btnPurgeLibs";
      this.btnPurgeLibs.Size = new System.Drawing.Size(75, 23);
      this.btnPurgeLibs.TabIndex = 12;
      this.btnPurgeLibs.Text = "&Purge";
      this.btnPurgeLibs.UseVisualStyleBackColor = true;
      this.btnPurgeLibs.Click += new System.EventHandler(this.PurgePcbLibs);
      // 
      // btnRemoveLib
      // 
      this.btnRemoveLib.Location = new System.Drawing.Point(197, 218);
      this.btnRemoveLib.Name = "btnRemoveLib";
      this.btnRemoveLib.Size = new System.Drawing.Size(75, 23);
      this.btnRemoveLib.TabIndex = 11;
      this.btnRemoveLib.Text = "&Remove";
      this.btnRemoveLib.UseVisualStyleBackColor = true;
      this.btnRemoveLib.Click += new System.EventHandler(this.RemovePcbLib);
      // 
      // listLibraries
      // 
      this.listLibraries.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem3});
      this.listLibraries.Location = new System.Drawing.Point(35, 115);
      this.listLibraries.Name = "listLibraries";
      this.listLibraries.Size = new System.Drawing.Size(227, 97);
      this.listLibraries.TabIndex = 10;
      this.listLibraries.UseCompatibleStateImageBehavior = false;
      this.listLibraries.View = System.Windows.Forms.View.List;
      this.listLibraries.SelectedIndexChanged += new System.EventHandler(this.EnableRemoveLibButton);
      // 
      // btnAddLib
      // 
      this.btnAddLib.Location = new System.Drawing.Point(35, 218);
      this.btnAddLib.Name = "btnAddLib";
      this.btnAddLib.Size = new System.Drawing.Size(75, 23);
      this.btnAddLib.TabIndex = 8;
      this.btnAddLib.Text = "&Add";
      this.btnAddLib.UseVisualStyleBackColor = true;
      this.btnAddLib.Click += new System.EventHandler(this.AddPcbLib);
      // 
      // lblFootprintCount
      // 
      this.lblFootprintCount.AutoSize = true;
      this.lblFootprintCount.Location = new System.Drawing.Point(32, 14);
      this.lblFootprintCount.Name = "lblFootprintCount";
      this.lblFootprintCount.Size = new System.Drawing.Size(172, 13);
      this.lblFootprintCount.TabIndex = 8;
      this.lblFootprintCount.Text = "A total of XX SMD footprints found!";
      // 
      // picLibNOK
      // 
      this.picLibNOK.Image = global::PnPConverter.Properties.Resources.nok;
      this.picLibNOK.Location = new System.Drawing.Point(96, 64);
      this.picLibNOK.Name = "picLibNOK";
      this.picLibNOK.Size = new System.Drawing.Size(45, 45);
      this.picLibNOK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picLibNOK.TabIndex = 9;
      this.picLibNOK.TabStop = false;
      // 
      // picLibOK
      // 
      this.picLibOK.Image = global::PnPConverter.Properties.Resources.ok;
      this.picLibOK.Location = new System.Drawing.Point(35, 64);
      this.picLibOK.Name = "picLibOK";
      this.picLibOK.Size = new System.Drawing.Size(45, 45);
      this.picLibOK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picLibOK.TabIndex = 8;
      this.picLibOK.TabStop = false;
      // 
      // pnlReviewParts
      // 
      this.pnlReviewParts.BackColor = System.Drawing.Color.LightCyan;
      this.pnlReviewParts.Controls.Add(this.btnOmitSelected);
      this.pnlReviewParts.Controls.Add(this.lnkOmittedParts);
      this.pnlReviewParts.Controls.Add(this.listPartSummary);
      this.pnlReviewParts.Controls.Add(this.label6);
      this.pnlReviewParts.Location = new System.Drawing.Point(12, 286);
      this.pnlReviewParts.Name = "pnlReviewParts";
      this.pnlReviewParts.Size = new System.Drawing.Size(315, 203);
      this.pnlReviewParts.TabIndex = 6;
      this.pnlReviewParts.Visible = false;
      // 
      // btnOmitSelected
      // 
      this.btnOmitSelected.Location = new System.Drawing.Point(18, 163);
      this.btnOmitSelected.Name = "btnOmitSelected";
      this.btnOmitSelected.Size = new System.Drawing.Size(75, 23);
      this.btnOmitSelected.TabIndex = 3;
      this.btnOmitSelected.Text = "&Omit selected";
      this.btnOmitSelected.UseVisualStyleBackColor = true;
      this.btnOmitSelected.Click += new System.EventHandler(this.OmitSelectedParts);
      // 
      // lnkOmittedParts
      // 
      this.lnkOmittedParts.AutoSize = true;
      this.lnkOmittedParts.Location = new System.Drawing.Point(172, 168);
      this.lnkOmittedParts.Name = "lnkOmittedParts";
      this.lnkOmittedParts.Size = new System.Drawing.Size(106, 13);
      this.lnkOmittedParts.TabIndex = 2;
      this.lnkOmittedParts.TabStop = true;
      this.lnkOmittedParts.Text = "Review omitted parts";
      this.lnkOmittedParts.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ReviewOmittedParts);
      // 
      // listPartSummary
      // 
      this.listPartSummary.CheckBoxes = true;
      this.listPartSummary.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
      listViewItem4.StateImageIndex = 0;
      this.listPartSummary.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem4});
      this.listPartSummary.Location = new System.Drawing.Point(18, 33);
      this.listPartSummary.Name = "listPartSummary";
      this.listPartSummary.Size = new System.Drawing.Size(260, 124);
      this.listPartSummary.TabIndex = 1;
      this.listPartSummary.UseCompatibleStateImageBehavior = false;
      this.listPartSummary.View = System.Windows.Forms.View.Details;
      this.listPartSummary.ItemChecked += new System.Windows.Forms.ItemCheckedEventHandler(this.EnableOmitSelectedButton);
      // 
      // columnHeader3
      // 
      this.columnHeader3.Text = "Designator";
      this.columnHeader3.Width = 78;
      // 
      // columnHeader4
      // 
      this.columnHeader4.Text = "Footprint";
      this.columnHeader4.Width = 90;
      // 
      // columnHeader5
      // 
      this.columnHeader5.Text = "Description";
      this.columnHeader5.Width = 133;
      // 
      // columnHeader6
      // 
      this.columnHeader6.Text = "Value";
      this.columnHeader6.Width = 73;
      // 
      // columnHeader7
      // 
      this.columnHeader7.Text = "Height";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(15, 17);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(35, 13);
      this.label6.TabIndex = 0;
      this.label6.Text = "label6";
      // 
      // pnlAddReels
      // 
      this.pnlAddReels.BackColor = System.Drawing.Color.Lavender;
      this.pnlAddReels.Controls.Add(this.lblMissingReels);
      this.pnlAddReels.Controls.Add(this.groupBox1);
      this.pnlAddReels.Controls.Add(this.listMissingReels);
      this.pnlAddReels.Location = new System.Drawing.Point(334, 286);
      this.pnlAddReels.Name = "pnlAddReels";
      this.pnlAddReels.Size = new System.Drawing.Size(748, 384);
      this.pnlAddReels.TabIndex = 7;
      this.pnlAddReels.Visible = false;
      // 
      // lblMissingReels
      // 
      this.lblMissingReels.AutoSize = true;
      this.lblMissingReels.Location = new System.Drawing.Point(12, 17);
      this.lblMissingReels.Name = "lblMissingReels";
      this.lblMissingReels.Size = new System.Drawing.Size(150, 13);
      this.lblMissingReels.TabIndex = 4;
      this.lblMissingReels.Text = "Loading available part library...";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.tabNewReel);
      this.groupBox1.Controls.Add(this.rdbExclude);
      this.groupBox1.Controls.Add(this.lblCurGUID);
      this.groupBox1.Controls.Add(this.rdbAddNew);
      this.groupBox1.Controls.Add(this.comCurReplace);
      this.groupBox1.Controls.Add(this.rdbReplacePart);
      this.groupBox1.Location = new System.Drawing.Point(350, 17);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(378, 359);
      this.groupBox1.TabIndex = 3;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "groupBox1";
      // 
      // tabNewReel
      // 
      this.tabNewReel.Controls.Add(this.tabPage1);
      this.tabNewReel.Controls.Add(this.tabPage2);
      this.tabNewReel.Location = new System.Drawing.Point(9, 124);
      this.tabNewReel.Name = "tabNewReel";
      this.tabNewReel.SelectedIndex = 0;
      this.tabNewReel.Size = new System.Drawing.Size(363, 203);
      this.tabNewReel.TabIndex = 5;
      // 
      // tabPage1
      // 
      this.tabPage1.Controls.Add(this.txtCurManufacturer);
      this.tabPage1.Controls.Add(this.lblCurManufacturer);
      this.tabPage1.Controls.Add(this.lblSupply);
      this.tabPage1.Controls.Add(this.comCurPackageType);
      this.tabPage1.Controls.Add(this.txtCurOrderCode);
      this.tabPage1.Controls.Add(this.lblCurSupplier);
      this.tabPage1.Controls.Add(this.lblCurOrderCode);
      this.tabPage1.Controls.Add(this.txtCurSupplier);
      this.tabPage1.Location = new System.Drawing.Point(4, 22);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage1.Size = new System.Drawing.Size(355, 177);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "Supply Chain";
      this.tabPage1.UseVisualStyleBackColor = true;
      // 
      // txtCurManufacturer
      // 
      this.txtCurManufacturer.Location = new System.Drawing.Point(91, 64);
      this.txtCurManufacturer.Name = "txtCurManufacturer";
      this.txtCurManufacturer.Size = new System.Drawing.Size(100, 20);
      this.txtCurManufacturer.TabIndex = 15;
      // 
      // lblCurManufacturer
      // 
      this.lblCurManufacturer.AutoSize = true;
      this.lblCurManufacturer.Location = new System.Drawing.Point(16, 67);
      this.lblCurManufacturer.Name = "lblCurManufacturer";
      this.lblCurManufacturer.Size = new System.Drawing.Size(73, 13);
      this.lblCurManufacturer.TabIndex = 2;
      this.lblCurManufacturer.Text = "Manufacturer:";
      // 
      // lblSupply
      // 
      this.lblSupply.AutoSize = true;
      this.lblSupply.Location = new System.Drawing.Point(12, 116);
      this.lblSupply.Name = "lblSupply";
      this.lblSupply.Size = new System.Drawing.Size(76, 13);
      this.lblSupply.TabIndex = 3;
      this.lblSupply.Text = "Package type:";
      // 
      // comCurPackageType
      // 
      this.comCurPackageType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comCurPackageType.FormattingEnabled = true;
      this.comCurPackageType.Items.AddRange(new object[] {
            "Reel, 8 mm",
            "Reel, 12 mm",
            "Reel, 16 mm",
            "Tube",
            "Tray"});
      this.comCurPackageType.Location = new System.Drawing.Point(91, 113);
      this.comCurPackageType.Name = "comCurPackageType";
      this.comCurPackageType.Size = new System.Drawing.Size(251, 21);
      this.comCurPackageType.TabIndex = 9;
      // 
      // txtCurOrderCode
      // 
      this.txtCurOrderCode.Location = new System.Drawing.Point(266, 88);
      this.txtCurOrderCode.Name = "txtCurOrderCode";
      this.txtCurOrderCode.Size = new System.Drawing.Size(62, 20);
      this.txtCurOrderCode.TabIndex = 19;
      // 
      // lblCurSupplier
      // 
      this.lblCurSupplier.AutoSize = true;
      this.lblCurSupplier.Location = new System.Drawing.Point(16, 88);
      this.lblCurSupplier.Name = "lblCurSupplier";
      this.lblCurSupplier.Size = new System.Drawing.Size(48, 13);
      this.lblCurSupplier.TabIndex = 16;
      this.lblCurSupplier.Text = "Supplier:";
      // 
      // lblCurOrderCode
      // 
      this.lblCurOrderCode.AutoSize = true;
      this.lblCurOrderCode.Location = new System.Drawing.Point(197, 91);
      this.lblCurOrderCode.Name = "lblCurOrderCode";
      this.lblCurOrderCode.Size = new System.Drawing.Size(63, 13);
      this.lblCurOrderCode.TabIndex = 18;
      this.lblCurOrderCode.Text = "Order code:";
      // 
      // txtCurSupplier
      // 
      this.txtCurSupplier.Location = new System.Drawing.Point(91, 88);
      this.txtCurSupplier.Name = "txtCurSupplier";
      this.txtCurSupplier.Size = new System.Drawing.Size(100, 20);
      this.txtCurSupplier.TabIndex = 17;
      // 
      // tabPage2
      // 
      this.tabPage2.Controls.Add(this.comCurNozzle);
      this.tabPage2.Controls.Add(this.comCurSpeed);
      this.tabPage2.Controls.Add(this.label9);
      this.tabPage2.Controls.Add(this.label8);
      this.tabPage2.Controls.Add(this.txtCurFeedSpacing);
      this.tabPage2.Controls.Add(this.label7);
      this.tabPage2.Controls.Add(this.txtCurYOffset);
      this.tabPage2.Controls.Add(this.txtCurXOffset);
      this.tabPage2.Controls.Add(this.lblMm);
      this.tabPage2.Controls.Add(this.lblHeight);
      this.tabPage2.Controls.Add(this.txtCurHeight);
      this.tabPage2.Controls.Add(this.lblCurSpeed);
      this.tabPage2.Controls.Add(this.label4);
      this.tabPage2.Controls.Add(this.lblCurFeedSpacing);
      this.tabPage2.Controls.Add(this.lblCurNozzle);
      this.tabPage2.Controls.Add(this.lblCurOffset);
      this.tabPage2.Location = new System.Drawing.Point(4, 22);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage2.Size = new System.Drawing.Size(355, 177);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "Placement";
      this.tabPage2.UseVisualStyleBackColor = true;
      // 
      // comCurNozzle
      // 
      this.comCurNozzle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comCurNozzle.FormattingEnabled = true;
      this.comCurNozzle.Items.AddRange(new object[] {
            "Large",
            "Medium",
            "Small",
            "Tiny"});
      this.comCurNozzle.Location = new System.Drawing.Point(75, 17);
      this.comCurNozzle.Name = "comCurNozzle";
      this.comCurNozzle.Size = new System.Drawing.Size(121, 21);
      this.comCurNozzle.TabIndex = 35;
      // 
      // comCurSpeed
      // 
      this.comCurSpeed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comCurSpeed.FormattingEnabled = true;
      this.comCurSpeed.Items.AddRange(new object[] {
            "Very Fast",
            "Fast",
            "Medium",
            "Slow",
            "Very Slow"});
      this.comCurSpeed.Location = new System.Drawing.Point(81, 115);
      this.comCurSpeed.Name = "comCurSpeed";
      this.comCurSpeed.Size = new System.Drawing.Size(121, 21);
      this.comCurSpeed.TabIndex = 34;
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Location = new System.Drawing.Point(214, 86);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(23, 13);
      this.label9.TabIndex = 33;
      this.label9.Text = "mm";
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(285, 47);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(23, 13);
      this.label8.TabIndex = 32;
      this.label8.Text = "mm";
      // 
      // txtCurFeedSpacing
      // 
      this.txtCurFeedSpacing.Location = new System.Drawing.Point(102, 83);
      this.txtCurFeedSpacing.Name = "txtCurFeedSpacing";
      this.txtCurFeedSpacing.Size = new System.Drawing.Size(65, 20);
      this.txtCurFeedSpacing.TabIndex = 31;
      this.txtCurFeedSpacing.Text = "4";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(162, 48);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(46, 13);
      this.label7.TabIndex = 30;
      this.label7.Text = "mm, y = ";
      // 
      // txtCurYOffset
      // 
      this.txtCurYOffset.Location = new System.Drawing.Point(214, 45);
      this.txtCurYOffset.Name = "txtCurYOffset";
      this.txtCurYOffset.Size = new System.Drawing.Size(65, 20);
      this.txtCurYOffset.TabIndex = 29;
      this.txtCurYOffset.Text = "0";
      // 
      // txtCurXOffset
      // 
      this.txtCurXOffset.Location = new System.Drawing.Point(91, 44);
      this.txtCurXOffset.Name = "txtCurXOffset";
      this.txtCurXOffset.Size = new System.Drawing.Size(65, 20);
      this.txtCurXOffset.TabIndex = 28;
      this.txtCurXOffset.Text = "0";
      // 
      // lblMm
      // 
      this.lblMm.AutoSize = true;
      this.lblMm.Location = new System.Drawing.Point(187, 151);
      this.lblMm.Name = "lblMm";
      this.lblMm.Size = new System.Drawing.Size(23, 13);
      this.lblMm.TabIndex = 27;
      this.lblMm.Text = "mm";
      // 
      // lblHeight
      // 
      this.lblHeight.AutoSize = true;
      this.lblHeight.Location = new System.Drawing.Point(26, 151);
      this.lblHeight.Name = "lblHeight";
      this.lblHeight.Size = new System.Drawing.Size(41, 13);
      this.lblHeight.TabIndex = 25;
      this.lblHeight.Text = "Height:";
      // 
      // txtCurHeight
      // 
      this.txtCurHeight.Location = new System.Drawing.Point(81, 148);
      this.txtCurHeight.Name = "txtCurHeight";
      this.txtCurHeight.Size = new System.Drawing.Size(100, 20);
      this.txtCurHeight.TabIndex = 26;
      // 
      // lblCurSpeed
      // 
      this.lblCurSpeed.AutoSize = true;
      this.lblCurSpeed.Location = new System.Drawing.Point(22, 115);
      this.lblCurSpeed.Name = "lblCurSpeed";
      this.lblCurSpeed.Size = new System.Drawing.Size(41, 13);
      this.lblCurSpeed.TabIndex = 23;
      this.lblCurSpeed.Text = "Speed:";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(202, 22);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(35, 13);
      this.label4.TabIndex = 24;
      this.label4.Text = "label4";
      // 
      // lblCurFeedSpacing
      // 
      this.lblCurFeedSpacing.AutoSize = true;
      this.lblCurFeedSpacing.Location = new System.Drawing.Point(22, 86);
      this.lblCurFeedSpacing.Name = "lblCurFeedSpacing";
      this.lblCurFeedSpacing.Size = new System.Drawing.Size(74, 13);
      this.lblCurFeedSpacing.TabIndex = 22;
      this.lblCurFeedSpacing.Text = "Feed spacing:";
      // 
      // lblCurNozzle
      // 
      this.lblCurNozzle.AutoSize = true;
      this.lblCurNozzle.Location = new System.Drawing.Point(22, 22);
      this.lblCurNozzle.Name = "lblCurNozzle";
      this.lblCurNozzle.Size = new System.Drawing.Size(42, 13);
      this.lblCurNozzle.TabIndex = 20;
      this.lblCurNozzle.Text = "Nozzle:";
      // 
      // lblCurOffset
      // 
      this.lblCurOffset.AutoSize = true;
      this.lblCurOffset.Location = new System.Drawing.Point(22, 47);
      this.lblCurOffset.Name = "lblCurOffset";
      this.lblCurOffset.Size = new System.Drawing.Size(55, 13);
      this.lblCurOffset.TabIndex = 21;
      this.lblCurOffset.Text = "Offset: x =";
      // 
      // rdbExclude
      // 
      this.rdbExclude.AutoSize = true;
      this.rdbExclude.Location = new System.Drawing.Point(32, 333);
      this.rdbExclude.Name = "rdbExclude";
      this.rdbExclude.Size = new System.Drawing.Size(251, 17);
      this.rdbExclude.TabIndex = 13;
      this.rdbExclude.Text = "E&xclude part from PnP file and place it manually.";
      this.rdbExclude.UseVisualStyleBackColor = true;
      this.rdbExclude.CheckedChanged += new System.EventHandler(this.ChangeSolution);
      // 
      // lblCurGUID
      // 
      this.lblCurGUID.AutoSize = true;
      this.lblCurGUID.Location = new System.Drawing.Point(26, 99);
      this.lblCurGUID.Name = "lblCurGUID";
      this.lblCurGUID.Size = new System.Drawing.Size(102, 13);
      this.lblCurGUID.TabIndex = 0;
      this.lblCurGUID.Text = "Unique reel ID: ABC";
      // 
      // rdbAddNew
      // 
      this.rdbAddNew.AutoSize = true;
      this.rdbAddNew.Location = new System.Drawing.Point(23, 69);
      this.rdbAddNew.Name = "rdbAddNew";
      this.rdbAddNew.Size = new System.Drawing.Size(178, 17);
      this.rdbAddNew.TabIndex = 6;
      this.rdbAddNew.Text = "Add a &new part to the collection:";
      this.rdbAddNew.UseVisualStyleBackColor = true;
      this.rdbAddNew.CheckedChanged += new System.EventHandler(this.ChangeSolution);
      // 
      // comCurReplace
      // 
      this.comCurReplace.FormattingEnabled = true;
      this.comCurReplace.Location = new System.Drawing.Point(34, 42);
      this.comCurReplace.Name = "comCurReplace";
      this.comCurReplace.Size = new System.Drawing.Size(301, 21);
      this.comCurReplace.TabIndex = 5;
      // 
      // rdbReplacePart
      // 
      this.rdbReplacePart.AutoSize = true;
      this.rdbReplacePart.Location = new System.Drawing.Point(23, 19);
      this.rdbReplacePart.Name = "rdbReplacePart";
      this.rdbReplacePart.Size = new System.Drawing.Size(226, 17);
      this.rdbReplacePart.TabIndex = 4;
      this.rdbReplacePart.Text = "Replace missing part with this e&xisting part:";
      this.rdbReplacePart.UseVisualStyleBackColor = true;
      this.rdbReplacePart.CheckedChanged += new System.EventHandler(this.ChangeSolution);
      // 
      // listMissingReels
      // 
      this.listMissingReels.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
      this.listMissingReels.FullRowSelect = true;
      this.listMissingReels.HideSelection = false;
      this.listMissingReels.Location = new System.Drawing.Point(15, 51);
      this.listMissingReels.Name = "listMissingReels";
      this.listMissingReels.Size = new System.Drawing.Size(329, 293);
      this.listMissingReels.TabIndex = 0;
      this.listMissingReels.UseCompatibleStateImageBehavior = false;
      this.listMissingReels.View = System.Windows.Forms.View.Details;
      this.listMissingReels.SelectedIndexChanged += new System.EventHandler(this.ConfigureReel);
      // 
      // columnHeader8
      // 
      this.columnHeader8.Text = "Parts";
      this.columnHeader8.Width = 91;
      // 
      // columnHeader9
      // 
      this.columnHeader9.Text = "Footprint";
      this.columnHeader9.Width = 113;
      // 
      // columnHeader10
      // 
      this.columnHeader10.Text = "Value";
      this.columnHeader10.Width = 115;
      // 
      // pnlProjectProperties
      // 
      this.pnlProjectProperties.BackColor = System.Drawing.Color.LightPink;
      this.pnlProjectProperties.Controls.Add(this.lblBoards);
      this.pnlProjectProperties.Controls.Add(this.numPCBCount);
      this.pnlProjectProperties.Controls.Add(this.txtProjectName);
      this.pnlProjectProperties.Controls.Add(this.label5);
      this.pnlProjectProperties.Controls.Add(this.lblProjectName);
      this.pnlProjectProperties.Location = new System.Drawing.Point(12, 497);
      this.pnlProjectProperties.Name = "pnlProjectProperties";
      this.pnlProjectProperties.Size = new System.Drawing.Size(315, 110);
      this.pnlProjectProperties.TabIndex = 8;
      this.pnlProjectProperties.Visible = false;
      // 
      // lblBoards
      // 
      this.lblBoards.AutoSize = true;
      this.lblBoards.Location = new System.Drawing.Point(186, 49);
      this.lblBoards.Name = "lblBoards";
      this.lblBoards.Size = new System.Drawing.Size(39, 13);
      this.lblBoards.TabIndex = 4;
      this.lblBoards.Text = "boards";
      // 
      // numPCBCount
      // 
      this.numPCBCount.Location = new System.Drawing.Point(102, 42);
      this.numPCBCount.Name = "numPCBCount";
      this.numPCBCount.Size = new System.Drawing.Size(78, 20);
      this.numPCBCount.TabIndex = 3;
      // 
      // txtProjectName
      // 
      this.txtProjectName.Location = new System.Drawing.Point(102, 14);
      this.txtProjectName.Name = "txtProjectName";
      this.txtProjectName.Size = new System.Drawing.Size(176, 20);
      this.txtProjectName.TabIndex = 2;
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(18, 49);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(78, 13);
      this.label5.TabIndex = 1;
      this.label5.Text = "Board quantity:";
      // 
      // lblProjectName
      // 
      this.lblProjectName.AutoSize = true;
      this.lblProjectName.Location = new System.Drawing.Point(18, 17);
      this.lblProjectName.Name = "lblProjectName";
      this.lblProjectName.Size = new System.Drawing.Size(72, 13);
      this.lblProjectName.TabIndex = 0;
      this.lblProjectName.Text = "Project name:";
      // 
      // pnlPhases
      // 
      this.pnlPhases.BackColor = System.Drawing.Color.SlateBlue;
      this.pnlPhases.Controls.Add(this.button1);
      this.pnlPhases.Controls.Add(this.lblUnassignedReels);
      this.pnlPhases.Controls.Add(this.btnReassignReels);
      this.pnlPhases.Controls.Add(this.tabPhases);
      this.pnlPhases.Location = new System.Drawing.Point(1088, 12);
      this.pnlPhases.Name = "pnlPhases";
      this.pnlPhases.Size = new System.Drawing.Size(257, 658);
      this.pnlPhases.TabIndex = 9;
      this.pnlPhases.Visible = false;
      // 
      // lblUnassignedReels
      // 
      this.lblUnassignedReels.AutoSize = true;
      this.lblUnassignedReels.Location = new System.Drawing.Point(14, 602);
      this.lblUnassignedReels.Name = "lblUnassignedReels";
      this.lblUnassignedReels.Size = new System.Drawing.Size(41, 13);
      this.lblUnassignedReels.TabIndex = 2;
      this.lblUnassignedReels.Text = "label10";
      // 
      // btnReassignReels
      // 
      this.btnReassignReels.Location = new System.Drawing.Point(133, 618);
      this.btnReassignReels.Name = "btnReassignReels";
      this.btnReassignReels.Size = new System.Drawing.Size(114, 23);
      this.btnReassignReels.TabIndex = 1;
      this.btnReassignReels.Text = "Check Con&figuration";
      this.btnReassignReels.UseVisualStyleBackColor = true;
      this.btnReassignReels.Click += new System.EventHandler(this.CheckReelConfigurationButton);
      // 
      // tabPhases
      // 
      this.tabPhases.Location = new System.Drawing.Point(14, 14);
      this.tabPhases.Name = "tabPhases";
      this.tabPhases.SelectedIndex = 0;
      this.tabPhases.Size = new System.Drawing.Size(233, 581);
      this.tabPhases.TabIndex = 0;
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(14, 618);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(75, 23);
      this.button1.TabIndex = 3;
      this.button1.Text = "button1";
      this.button1.UseVisualStyleBackColor = true;
      // 
      // NewProjectWizard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1352, 691);
      this.Controls.Add(this.pnlPhases);
      this.Controls.Add(this.pnlProjectProperties);
      this.Controls.Add(this.pnlAddReels);
      this.Controls.Add(this.pnlReviewParts);
      this.Controls.Add(this.pnlSelectLib);
      this.Controls.Add(this.pnlSelectPnP);
      this.Controls.Add(this.pnlIntro);
      this.Controls.Add(this.btnBack);
      this.Controls.Add(this.btnNext);
      this.Controls.Add(this.btnCancel);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.Name = "NewProjectWizard";
      this.Text = "NewPCBWizard";
      this.Load += new System.EventHandler(this.NewPCBWizard_Load);
      this.pnlIntro.ResumeLayout(false);
      this.pnlIntro.PerformLayout();
      this.pnlSelectPnP.ResumeLayout(false);
      this.pnlSelectPnP.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.picPnPOK)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.picPnPNOK)).EndInit();
      this.pnlSelectLib.ResumeLayout(false);
      this.pnlSelectLib.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.picLibNOK)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.picLibOK)).EndInit();
      this.pnlReviewParts.ResumeLayout(false);
      this.pnlReviewParts.PerformLayout();
      this.pnlAddReels.ResumeLayout(false);
      this.pnlAddReels.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.tabNewReel.ResumeLayout(false);
      this.tabPage1.ResumeLayout(false);
      this.tabPage1.PerformLayout();
      this.tabPage2.ResumeLayout(false);
      this.tabPage2.PerformLayout();
      this.pnlProjectProperties.ResumeLayout(false);
      this.pnlProjectProperties.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numPCBCount)).EndInit();
      this.pnlPhases.ResumeLayout(false);
      this.pnlPhases.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.Button btnNext;
    private System.Windows.Forms.Button btnBack;
    private System.Windows.Forms.Panel pnlIntro;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Panel pnlSelectPnP;
    private System.Windows.Forms.Button btnBrowsePnPFile;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox txtPnPFile;
    private System.Windows.Forms.ListView listPartPreview;
    private System.Windows.Forms.ColumnHeader columnHeader1;
    private System.Windows.Forms.Label lblPartPreviewMessage;
    private System.Windows.Forms.Panel pnlSelectLib;
    private System.Windows.Forms.ColumnHeader columnHeader2;
    private System.Windows.Forms.PictureBox picPnPNOK;
    private System.Windows.Forms.PictureBox picPnPOK;
    private System.Windows.Forms.Button btnAddLib;
    private System.Windows.Forms.Label lblFootprintCount;
    private System.Windows.Forms.PictureBox picLibNOK;
    private System.Windows.Forms.PictureBox picLibOK;
    private System.Windows.Forms.ListView listLibraries;
    private System.Windows.Forms.Button btnPurgeLibs;
    private System.Windows.Forms.Button btnRemoveLib;
    private System.Windows.Forms.Panel pnlReviewParts;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.ListView listPartSummary;
    private System.Windows.Forms.ColumnHeader columnHeader3;
    private System.Windows.Forms.ColumnHeader columnHeader4;
    private System.Windows.Forms.ColumnHeader columnHeader5;
    private System.Windows.Forms.ColumnHeader columnHeader6;
    private System.Windows.Forms.ColumnHeader columnHeader7;
    private System.Windows.Forms.LinkLabel lnkOmittedParts;
    private System.Windows.Forms.Label lblADLib;
    private System.Windows.Forms.Button btnOmitSelected;
    private System.Windows.Forms.Panel pnlAddReels;
    private System.Windows.Forms.Panel pnlProjectProperties;
    private System.Windows.Forms.Label lblBoards;
    private System.Windows.Forms.NumericUpDown numPCBCount;
    private System.Windows.Forms.TextBox txtProjectName;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label lblProjectName;
    private System.Windows.Forms.ListView listMissingReels;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.RadioButton rdbExclude;
    private System.Windows.Forms.Label lblCurGUID;
    private System.Windows.Forms.ComboBox comCurPackageType;
    private System.Windows.Forms.RadioButton rdbAddNew;
    private System.Windows.Forms.ComboBox comCurReplace;
    private System.Windows.Forms.RadioButton rdbReplacePart;
    private System.Windows.Forms.Label lblSupply;
    private System.Windows.Forms.Label lblCurManufacturer;
    private System.Windows.Forms.ColumnHeader columnHeader8;
    private System.Windows.Forms.ColumnHeader columnHeader9;
    private System.Windows.Forms.ColumnHeader columnHeader10;
    private System.Windows.Forms.Label lblMissingReels;
    private System.Windows.Forms.Label lblCurOrderCode;
    private System.Windows.Forms.TextBox txtCurSupplier;
    private System.Windows.Forms.Label lblCurSupplier;
    private System.Windows.Forms.TextBox txtCurManufacturer;
    private System.Windows.Forms.TabControl tabNewReel;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.TabPage tabPage2;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label lblCurSpeed;
    private System.Windows.Forms.Label lblCurFeedSpacing;
    private System.Windows.Forms.Label lblCurOffset;
    private System.Windows.Forms.Label lblCurNozzle;
    private System.Windows.Forms.TextBox txtCurOrderCode;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.TextBox txtCurFeedSpacing;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.TextBox txtCurYOffset;
    private System.Windows.Forms.TextBox txtCurXOffset;
    private System.Windows.Forms.Label lblMm;
    private System.Windows.Forms.Label lblHeight;
    private System.Windows.Forms.TextBox txtCurHeight;
    private System.Windows.Forms.ComboBox comCurNozzle;
    private System.Windows.Forms.ComboBox comCurSpeed;
    private System.Windows.Forms.Panel pnlPhases;
    private System.Windows.Forms.TabControl tabPhases;
    private System.Windows.Forms.Button btnReassignReels;
    private System.Windows.Forms.Label lblUnassignedReels;
    private System.Windows.Forms.Button button1;
  }
}